#!/usr/bin/env bash
set -e

cat > inventory_editor/models/project.py <<'EOF'
from dataclasses import dataclass, field

from inventory_editor.models.group import Group
from inventory_editor.models.host import Host
from inventory_editor.models.variable import Variable, VariableScope


@dataclass(slots=True)
class ProjectModel:
    root_path: str
    inventory_file: str = "inventory.yml"

    groups: dict[str, Group] = field(default_factory=dict)
    hosts: dict[str, Host] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if "all" not in self.groups:
            self.groups["all"] = Group(name="all")

    def add_group(self, group_name: str) -> Group:
        if group_name in self.groups:
            return self.groups[group_name]

        group = Group(name=group_name)
        self.groups[group_name] = group
        return group

    def add_host(self, host_name: str) -> Host:
        if host_name in self.hosts:
            return self.hosts[host_name]

        host = Host(name=host_name)
        self.hosts[host_name] = host
        return host

    def assign_host_to_group(self, host_name: str, group_name: str) -> None:
        host = self.add_host(host_name)
        group = self.add_group(group_name)

        host.add_group(group_name)
        group.add_host(host_name)

    def add_variable_to_group(self, group_name: str, variable: Variable) -> None:
        group = self.add_group(group_name)
        if variable.scope != VariableScope.GROUP:
            raise ValueError("Variable scope must be GROUP for group variables")
        group.add_variable(variable)

    def add_variable_to_host(self, host_name: str, variable: Variable) -> None:
        host = self.add_host(host_name)
        if variable.scope != VariableScope.HOST:
            raise ValueError("Variable scope must be HOST for host variables")
        host.add_variable(variable)

    def effective_variables_for_host(self, host_name: str) -> dict[str, Variable]:
        if host_name not in self.hosts:
            raise KeyError(f"Unknown host: {host_name}")

        host = self.hosts[host_name]
        merged: dict[str, Variable] = {}

        all_group = self.groups.get("all")
        if all_group is not None:
            for variable in all_group.variables:
                merged[variable.key] = variable

        for group_name in sorted(host.groups):
            group = self.groups.get(group_name)
            if group is None:
                continue
            for variable in group.variables:
                merged[variable.key] = variable

        for variable in host.variables:
            merged[variable.key] = variable

        return merged

    def group_count(self) -> int:
        return len(self.groups)

    def host_count(self) -> int:
        return len(self.hosts)
EOF

cat > inventory_editor/tests/test_effective_variables.py <<'EOF'
from inventory_editor.models.project import ProjectModel
from inventory_editor.models.variable import Variable, VariableScope, VariableSource


def test_effective_variables_host_over_group_over_all():
    model = ProjectModel(root_path=".")

    model.add_variable_to_group(
        "all",
        Variable(
            key="http_port",
            value=80,
            scope=VariableScope.GROUP,
            owner="all",
            source=VariableSource(
                source_path="group_vars/all/main.yml",
                source_type="group_vars",
            ),
        ),
    )

    model.add_variable_to_group(
        "web",
        Variable(
            key="http_port",
            value=8080,
            scope=VariableScope.GROUP,
            owner="web",
            source=VariableSource(
                source_path="group_vars/web/main.yml",
                source_type="group_vars",
            ),
        ),
    )

    model.assign_host_to_group("web01", "web")

    model.add_variable_to_host(
        "web01",
        Variable(
            key="http_port",
            value=9090,
            scope=VariableScope.HOST,
            owner="web01",
            source=VariableSource(
                source_path="host_vars/web01/main.yml",
                source_type="host_vars",
            ),
        ),
    )

    effective = model.effective_variables_for_host("web01")

    assert effective["http_port"].value == 9090
    assert effective["http_port"].source.source_path == "host_vars/web01/main.yml"
EOF

echo "RELEASE-0006 applied"
