#!/usr/bin/env bash
set -e

cat > inventory_editor/analyzer/reporting.py <<'EOF'
from inventory_editor.analyzer.tracing import trace_variables_for_host
from inventory_editor.models.project import ProjectModel


def explain_variable_for_host(project: ProjectModel, host_name: str, key: str) -> str:
    traced = trace_variables_for_host(project, host_name)

    for item in traced:
        if item.key != key:
            continue

        lines = [
            f"Host: {host_name}",
            f"Variable: {key}",
            f"Effective value: {item.effective.value}",
            f"Effective source: {item.effective.source.source_path}",
            "Trace:",
        ]

        for variable in item.sources:
            lines.append(f"  - {variable.source.source_path}: {variable.value}")

        if item.overridden_by:
            lines.append("Overridden by:")
            for variable in item.overridden_by:
                lines.append(f"  - {variable.source.source_path}: {variable.value}")

        return "\n".join(lines)

    return f"Variable '{key}' not found for host '{host_name}'"
EOF

cat > inventory_editor/tests/test_reporting.py <<'EOF'
from inventory_editor.analyzer.reporting import explain_variable_for_host
from inventory_editor.models.project import ProjectModel
from inventory_editor.models.variable import Variable, VariableScope, VariableSource


def test_explain_variable_for_host():
    model = ProjectModel(root_path=".")

    model.add_variable_to_group(
        "all",
        Variable(
            key="http_port",
            value=80,
            scope=VariableScope.GROUP,
            owner="all",
            source=VariableSource(
                source_path="group_vars/all/main.yml",
                source_type="group_vars",
            ),
        ),
    )

    model.assign_host_to_group("web01", "web")

    model.add_variable_to_host(
        "web01",
        Variable(
            key="http_port",
            value=9090,
            scope=VariableScope.HOST,
            owner="web01",
            source=VariableSource(
                source_path="host_vars/web01/main.yml",
                source_type="host_vars",
            ),
        ),
    )

    report = explain_variable_for_host(model, "web01", "http_port")

    assert "Effective value: 9090" in report
    assert "group_vars/all/main.yml" in report
    assert "host_vars/web01/main.yml" in report
EOF

echo "RELEASE-0012 applied"
