#!/usr/bin/env bash
set -e

cat > inventory_editor/analyzer/placement.py <<'EOF'
from dataclasses import dataclass
from enum import Enum

from inventory_editor.models.project import ProjectModel


class PlacementScope(str, Enum):
    ALL = "all"
    GROUP = "group"
    HOST = "host"


class ConflictAction(str, Enum):
    KEEP = "keep"
    OVERWRITE = "overwrite"
    MOVE = "move"
    NONE = "none"


@dataclass(slots=True)
class PlacementCandidate:
    scope: PlacementScope
    owner: str
    target_file: str


@dataclass(slots=True)
class VariableConflict:
    key: str
    existing_value: object
    owner: str
    source_path: str


def suggest_placements(
    project: ProjectModel,
    host_name: str,
) -> list[PlacementCandidate]:

    if host_name not in project.hosts:
        return []

    host = project.hosts[host_name]

    candidates = [
        PlacementCandidate(
            scope=PlacementScope.ALL,
            owner="all",
            target_file="group_vars/all/main.yml",
        )
    ]

    for group_name in sorted(host.groups):
        candidates.append(
            PlacementCandidate(
                scope=PlacementScope.GROUP,
                owner=group_name,
                target_file=f"group_vars/{group_name}/main.yml",
            )
        )

    candidates.append(
        PlacementCandidate(
            scope=PlacementScope.HOST,
            owner=host_name,
            target_file=f"host_vars/{host_name}/main.yml",
        )
    )

    return candidates


def find_variable_conflicts(
    project: ProjectModel,
    host_name: str,
    key: str,
) -> list[VariableConflict]:

    conflicts: list[VariableConflict] = []

    if host_name not in project.hosts:
        return conflicts

    host = project.hosts[host_name]

    for variable in host.variables:
        if variable.key == key:
            conflicts.append(
                VariableConflict(
                    key=key,
                    existing_value=variable.value,
                    owner=host_name,
                    source_path=variable.source.source_path,
                )
            )

    for group_name in host.groups:
        group = project.groups.get(group_name)
        if group is None:
            continue

        for variable in group.variables:
            if variable.key == key:
                conflicts.append(
                    VariableConflict(
                        key=key,
                        existing_value=variable.value,
                        owner=group_name,
                        source_path=variable.source.source_path,
                    )
                )

    return conflicts
EOF

cat > inventory_editor/tests/test_placement.py <<'EOF'
from inventory_editor.analyzer.placement import (
    PlacementScope,
    find_variable_conflicts,
    suggest_placements,
)
from inventory_editor.models.project import ProjectModel
from inventory_editor.models.variable import (
    Variable,
    VariableScope,
    VariableSource,
)


def test_suggest_placements():
    model = ProjectModel(root_path=".")

    model.assign_host_to_group(
        "web01",
        "web",
    )

    placements = suggest_placements(
        model,
        "web01",
    )

    assert len(placements) == 3

    assert placements[0].scope == PlacementScope.ALL
    assert placements[1].scope == PlacementScope.GROUP
    assert placements[2].scope == PlacementScope.HOST


def test_find_variable_conflicts():
    model = ProjectModel(root_path=".")

    model.assign_host_to_group(
        "web01",
        "web",
    )

    model.add_variable_to_group(
        "web",
        Variable(
            key="http_port",
            value=80,
            scope=VariableScope.GROUP,
            owner="web",
            source=VariableSource(
                source_path="group_vars/web/main.yml",
                source_type="group_vars",
            ),
        ),
    )

    conflicts = find_variable_conflicts(
        model,
        "web01",
        "http_port",
    )

    assert len(conflicts) == 1
    assert conflicts[0].owner == "web"
EOF

echo "RELEASE-0027 applied"
