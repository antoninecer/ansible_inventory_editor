#!/usr/bin/env bash
set -e

cat > inventory_editor/analyzer/tracing.py <<'EOF'
from dataclasses import dataclass

from inventory_editor.models.project import ProjectModel
from inventory_editor.models.variable import Variable


@dataclass(slots=True)
class TracedVariable:
    key: str
    effective: Variable
    sources: list[Variable]
    overridden_by: list[Variable]


def trace_variables_for_host(project: ProjectModel, host_name: str) -> list[TracedVariable]:
    if host_name not in project.hosts:
        raise KeyError(f"Unknown host: {host_name}")

    host = project.hosts[host_name]
    traced: dict[str, TracedVariable] = {}

    all_group = project.groups.get("all")
    if all_group is not None:
        for variable in all_group.variables:
            traced[variable.key] = TracedVariable(
                key=variable.key,
                effective=variable,
                sources=[variable],
                overridden_by=[],
            )

    for group_name in sorted(host.groups):
        group = project.groups.get(group_name)
        if group is None:
            continue
        for variable in group.variables:
            if variable.key in traced:
                traced[variable.key].overridden_by.append(variable)
                traced[variable.key].effective = variable
                traced[variable.key].sources.append(variable)
            else:
                traced[variable.key] = TracedVariable(
                    key=variable.key,
                    effective=variable,
                    sources=[variable],
                    overridden_by=[],
                )

    for variable in host.variables:
        if variable.key in traced:
            traced[variable.key].overridden_by.append(variable)
            traced[variable.key].effective = variable
            traced[variable.key].sources.append(variable)
        else:
            traced[variable.key] = TracedVariable(
                key=variable.key,
                effective=variable,
                sources=[variable],
                overridden_by=[],
            )

    return list(traced.values())
EOF

cat > inventory_editor/tests/test_tracing.py <<'EOF'
from inventory_editor.analyzer.tracing import trace_variables_for_host
from inventory_editor.models.project import ProjectModel
from inventory_editor.models.variable import Variable, VariableScope, VariableSource


def test_trace_variables_for_host():
    model = ProjectModel(root_path=".")

    model.add_variable_to_group(
        "all",
        Variable(
            key="http_port",
            value=80,
            scope=VariableScope.GROUP,
            owner="all",
            source=VariableSource(
                source_path="group_vars/all/main.yml",
                source_type="group_vars",
            ),
        ),
    )

    model.add_variable_to_group(
        "web",
        Variable(
            key="http_port",
            value=8080,
            scope=VariableScope.GROUP,
            owner="web",
            source=VariableSource(
                source_path="group_vars/web/main.yml",
                source_type="group_vars",
            ),
        ),
    )

    model.assign_host_to_group("web01", "web")

    model.add_variable_to_host(
        "web01",
        Variable(
            key="http_port",
            value=9090,
            scope=VariableScope.HOST,
            owner="web01",
            source=VariableSource(
                source_path="host_vars/web01/main.yml",
                source_type="host_vars",
            ),
        ),
    )

    traced = trace_variables_for_host(model, "web01")

    assert len(traced) == 1
    assert traced[0].effective.value == 9090
    assert traced[0].sources[0].source.source_path == "group_vars/all/main.yml"
    assert traced[0].sources[-1].source.source_path == "host_vars/web01/main.yml"
EOF

echo "RELEASE-0011 applied"
