#!/usr/bin/env bash
set -e

cat > inventory_editor/models/group.py <<'EOF'
from dataclasses import dataclass, field

from inventory_editor.models.variable import Variable


@dataclass(slots=True)
class Group:
    name: str

    hosts: set[str] = field(default_factory=set)
    children: set[str] = field(default_factory=set)

    variables: list[Variable] = field(default_factory=list)

    def add_host(self, host_name: str) -> None:
        self.hosts.add(host_name)

    def add_child(self, group_name: str) -> None:
        self.children.add(group_name)

    def add_variable(self, variable: Variable) -> None:
        self.variables.append(variable)
EOF

cat > inventory_editor/models/host.py <<'EOF'
from dataclasses import dataclass, field

from inventory_editor.models.variable import Variable


@dataclass(slots=True)
class Host:
    name: str

    groups: set[str] = field(default_factory=set)

    variables: list[Variable] = field(default_factory=list)

    def add_group(self, group_name: str) -> None:
        self.groups.add(group_name)

    def add_variable(self, variable: Variable) -> None:
        self.variables.append(variable)
EOF

cat > inventory_editor/models/project.py <<'EOF'
from dataclasses import dataclass, field

from inventory_editor.models.group import Group
from inventory_editor.models.host import Host
from inventory_editor.models.variable import Variable, VariableScope


@dataclass(slots=True)
class ProjectModel:
    root_path: str
    inventory_file: str = "inventory.yml"

    groups: dict[str, Group] = field(default_factory=dict)
    hosts: dict[str, Host] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if "all" not in self.groups:
            self.groups["all"] = Group(name="all")

    def add_group(self, group_name: str) -> Group:
        if group_name in self.groups:
            return self.groups[group_name]

        group = Group(name=group_name)
        self.groups[group_name] = group
        return group

    def add_host(self, host_name: str) -> Host:
        if host_name in self.hosts:
            return self.hosts[host_name]

        host = Host(name=host_name)
        self.hosts[host_name] = host
        return host

    def assign_host_to_group(self, host_name: str, group_name: str) -> None:
        host = self.add_host(host_name)
        group = self.add_group(group_name)

        host.add_group(group_name)
        group.add_host(host_name)

    def add_variable_to_group(self, group_name: str, variable: Variable) -> None:
        group = self.add_group(group_name)
        if variable.scope != VariableScope.GROUP:
            raise ValueError("Variable scope must be GROUP for group variables")
        group.add_variable(variable)

    def add_variable_to_host(self, host_name: str, variable: Variable) -> None:
        host = self.add_host(host_name)
        if variable.scope != VariableScope.HOST:
            raise ValueError("Variable scope must be HOST for host variables")
        host.add_variable(variable)

    def group_count(self) -> int:
        return len(self.groups)

    def host_count(self) -> int:
        return len(self.hosts)
EOF

cat > inventory_editor/tests/test_variables_ownership.py <<'EOF'
from inventory_editor.models.project import ProjectModel
from inventory_editor.models.variable import Variable, VariableScope, VariableSource


def test_add_group_variable():
    model = ProjectModel(root_path=".")

    variable = Variable(
        key="web_port",
        value=80,
        scope=VariableScope.GROUP,
        owner="web",
        source=VariableSource(
            source_path="group_vars/web/main.yml",
            source_type="group_vars",
        ),
    )

    model.add_variable_to_group("web", variable)

    assert "web" in model.groups
    assert len(model.groups["web"].variables) == 1


def test_add_host_variable():
    model = ProjectModel(root_path=".")

    variable = Variable(
        key="nginx_port",
        value=8080,
        scope=VariableScope.HOST,
        owner="web01",
        source=VariableSource(
            source_path="host_vars/web01/main.yml",
            source_type="host_vars",
        ),
    )

    model.add_variable_to_host("web01", variable)

    assert "web01" in model.hosts
    assert len(model.hosts["web01"].variables) == 1
EOF

echo "RELEASE-0005 applied"
