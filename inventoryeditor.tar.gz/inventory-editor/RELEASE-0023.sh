#!/usr/bin/env bash
set -e

cat > inventory_editor/models/vault.py <<'EOF'
from dataclasses import dataclass


@dataclass(slots=True)
class VaultFile:
    source_path: str
    vault_header: str
    vault_version: str
    cipher: str
EOF

cat > inventory_editor/analyzer/vault.py <<'EOF'
from pathlib import Path

from inventory_editor.models.vault import VaultFile


def detect_vault_file(path: str | Path) -> VaultFile | None:
    p = Path(path)

    try:
        first_line = p.read_text(
            encoding="utf-8",
            errors="ignore",
        ).splitlines()[0]
    except Exception:
        return None

    if not first_line.startswith("$ANSIBLE_VAULT;"):
        return None

    parts = first_line.split(";")

    version = "unknown"
    cipher = "unknown"

    if len(parts) >= 2:
        version = parts[1]

    if len(parts) >= 3:
        cipher = parts[2]

    return VaultFile(
        source_path=str(p),
        vault_header=first_line,
        vault_version=version,
        cipher=cipher,
    )
EOF

cat > inventory_editor/tests/test_vault_detection.py <<'EOF'
from inventory_editor.analyzer.vault import detect_vault_file


def test_detect_ansible_vault(tmp_path):
    vault_file = tmp_path / "vault.yml"

    vault_file.write_text(
        "$ANSIBLE_VAULT;1.1;AES256\n"
        "abcdef\n",
        encoding="utf-8",
    )

    vault = detect_vault_file(vault_file)

    assert vault is not None
    assert vault.vault_version == "1.1"
    assert vault.cipher == "AES256"
EOF

echo "RELEASE-0023 applied"
