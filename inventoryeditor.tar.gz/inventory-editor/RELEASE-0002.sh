#!/usr/bin/env bash
set -e

cat > inventory_editor/models/project.py <<'EOF'
from dataclasses import dataclass, field

from inventory_editor.models.group import Group
from inventory_editor.models.host import Host


@dataclass(slots=True)
class ProjectModel:
    root_path: str
    inventory_file: str = "inventory.yml"

    groups: dict[str, Group] = field(default_factory=dict)
    hosts: dict[str, Host] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if "all" not in self.groups:
            self.groups["all"] = Group(name="all")

    def add_group(self, group_name: str) -> Group:
        if group_name in self.groups:
            return self.groups[group_name]

        group = Group(name=group_name)
        self.groups[group_name] = group
        return group

    def add_host(self, host_name: str) -> Host:
        if host_name in self.hosts:
            return self.hosts[host_name]

        host = Host(name=host_name)
        self.hosts[host_name] = host
        return host

    def group_count(self) -> int:
        return len(self.groups)

    def host_count(self) -> int:
        return len(self.hosts)
EOF

cat > inventory_editor/tests/test_project_model.py <<'EOF'
from inventory_editor.models.project import ProjectModel


def test_project_contains_all_group():
    model = ProjectModel(root_path=".")

    assert "all" in model.groups
    assert model.group_count() == 1


def test_add_host():
    model = ProjectModel(root_path=".")

    model.add_host("server01")

    assert model.host_count() == 1
EOF

echo "RELEASE-0002 applied"
