#!/usr/bin/env bash
set -e

cat > inventory_editor/io/inventory_loader.py <<'EOF'
from __future__ import annotations

from pathlib import Path

from ruamel.yaml import YAML

from inventory_editor.models.project import ProjectModel
from inventory_editor.models.variable import Variable, VariableScope, VariableSource


yaml = YAML(typ="safe")


def _load_yaml_mapping(path: Path) -> dict:
    data = yaml.load(path.read_text(encoding="utf-8")) or {}
    if not isinstance(data, dict):
        raise ValueError(f"YAML root in {path} must be a mapping")
    return data


def load_inventory_file(path: str | Path) -> ProjectModel:
    inventory_path = Path(path).expanduser().resolve()
    if not inventory_path.exists():
        raise FileNotFoundError(inventory_path)

    data = _load_yaml_mapping(inventory_path)

    project = ProjectModel(root_path=str(inventory_path.parent), inventory_file=inventory_path.name)

    for group_name, group_data in data.items():
        if not isinstance(group_data, dict):
            continue

        project.add_group(group_name)

        hosts = group_data.get("hosts", {})
        if isinstance(hosts, dict):
            for host_name in hosts.keys():
                project.assign_host_to_group(host_name, group_name)

        children = group_data.get("children", {})
        if isinstance(children, dict):
            for child_name in children.keys():
                project.add_group(child_name)
                project.groups[group_name].add_child(child_name)

    return project


def load_workspace_variables(project: ProjectModel, workspace_root: str | Path) -> None:
    root = Path(workspace_root).expanduser().resolve()
    if not root.exists():
        raise FileNotFoundError(root)

    group_vars_root = root / "group_vars"
    if group_vars_root.exists():
        for group_dir in group_vars_root.iterdir():
            if not group_dir.is_dir():
                continue
            group_name = group_dir.name
            for file_path in sorted(group_dir.glob("*.yml")) + sorted(group_dir.glob("*.yaml")):
                data = _load_yaml_mapping(file_path)
                for key, value in data.items():
                    variable = Variable(
                        key=key,
                        value=value,
                        scope=VariableScope.GROUP,
                        owner=group_name,
                        source=VariableSource(
                            source_path=str(file_path.relative_to(root)),
                            source_type="group_vars",
                        ),
                    )
                    project.add_variable_to_group(group_name, variable)

    host_vars_root = root / "host_vars"
    if host_vars_root.exists():
        for host_dir in host_vars_root.iterdir():
            if not host_dir.is_dir():
                continue
            host_name = host_dir.name
            for file_path in sorted(host_dir.glob("*.yml")) + sorted(host_dir.glob("*.yaml")):
                data = _load_yaml_mapping(file_path)
                for key, value in data.items():
                    variable = Variable(
                        key=key,
                        value=value,
                        scope=VariableScope.HOST,
                        owner=host_name,
                        source=VariableSource(
                            source_path=str(file_path.relative_to(root)),
                            source_type="host_vars",
                        ),
                    )
                    project.add_variable_to_host(host_name, variable)
EOF

cat > inventory_editor/tests/test_workspace_variables.py <<'EOF'
from inventory_editor.io.inventory_loader import load_inventory_file, load_workspace_variables


def test_load_workspace_variables(tmp_path):
    root = tmp_path / "inventory"
    (root / "group_vars" / "web").mkdir(parents=True)
    (root / "host_vars" / "web01").mkdir(parents=True)

    (root / "inventory.yml").write_text(
        """
web:
  hosts:
    web01:
""".strip() + "\n",
        encoding="utf-8",
    )

    (root / "group_vars" / "web" / "main.yml").write_text("http_port: 80\n", encoding="utf-8")
    (root / "host_vars" / "web01" / "main.yml").write_text("http_port: 8080\n", encoding="utf-8")

    project = load_inventory_file(root / "inventory.yml")
    load_workspace_variables(project, root)

    assert project.groups["web"].variables[0].value == 80
    assert project.hosts["web01"].variables[0].value == 8080
EOF

echo "RELEASE-0010 applied"
