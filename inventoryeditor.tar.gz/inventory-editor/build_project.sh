#!/usr/bin/env bash
set -e

mkdir -p inventory_editor/models
mkdir -p inventory_editor/tests

cat > inventory_editor/models/variable.py <<'EOF'
from dataclasses import dataclass


@dataclass(slots=True)
class VariableSource:
    source_path: str
    source_type: str


@dataclass(slots=True)
class Variable:
    key: str
    value: object
    source: VariableSource
EOF

cat > inventory_editor/models/host.py <<'EOF'
from dataclasses import dataclass, field

from inventory_editor.models.variable import Variable


@dataclass(slots=True)
class Host:
    name: str

    groups: set[str] = field(default_factory=set)

    variables: list[Variable] = field(default_factory=list)

    def add_group(self, group_name: str) -> None:
        self.groups.add(group_name)

    def add_variable(self, variable: Variable) -> None:
        self.variables.append(variable)
EOF

cat > inventory_editor/models/group.py <<'EOF'
from dataclasses import dataclass, field

from inventory_editor.models.variable import Variable


@dataclass(slots=True)
class Group:
    name: str

    hosts: set[str] = field(default_factory=set)
    children: set[str] = field(default_factory=set)

    variables: list[Variable] = field(default_factory=list)

    def add_host(self, host_name: str) -> None:
        self.hosts.add(host_name)

    def add_child(self, group_name: str) -> None:
        self.children.add(group_name)

    def add_variable(self, variable: Variable) -> None:
        self.variables.append(variable)
EOF

cat > inventory_editor/models/project.py <<'EOF'
from dataclasses import dataclass, field

from inventory_editor.models.group import Group
from inventory_editor.models.host import Host


@dataclass(slots=True)
class ProjectModel:
    root_path: str
    inventory_file: str = "inventory.yml"

    groups: dict[str, Group] = field(default_factory=dict)
    hosts: dict[str, Host] = field(default_factory=dict)

    def add_group(self, group_name: str) -> Group:
        group = Group(name=group_name)
        self.groups[group_name] = group
        return group

    def add_host(self, host_name: str) -> Host:
        host = Host(name=host_name)
        self.hosts[host_name] = host
        return host

    def group_count(self) -> int:
        return len(self.groups)

    def host_count(self) -> int:
        return len(self.hosts)
EOF

cat > inventory_editor/tests/test_project_model.py <<'EOF'
from inventory_editor.models.project import ProjectModel


def test_empty_project():
    model = ProjectModel(root_path=".")

    assert model.group_count() == 0
    assert model.host_count() == 0
EOF

echo
echo "Project files generated."
echo
echo "Run:"
echo "pytest -v"
