#!/usr/bin/env bash
set -e

mkdir -p inventory_editor/analyzer

cat > inventory_editor/analyzer/issues.py <<'EOF'
from dataclasses import dataclass
from enum import Enum


class IssueSeverity(str, Enum):
    A = "A"
    B = "B"
    C = "C"


@dataclass(slots=True)
class Issue:
    severity: IssueSeverity
    message: str
    source_path: str | None = None
EOF

cat > inventory_editor/analyzer/conflicts.py <<'EOF'
from collections import defaultdict

from inventory_editor.analyzer.issues import Issue, IssueSeverity
from inventory_editor.models.project import ProjectModel


def find_conflicts(project: ProjectModel) -> list[Issue]:
    issues: list[Issue] = []

    for group_name, group in project.groups.items():
        seen: dict[str, int] = defaultdict(int)
        for variable in group.variables:
            seen[variable.key] += 1
        for key, count in seen.items():
            if count > 1:
                issues.append(
                    Issue(
                        severity=IssueSeverity.B,
                        message=f"Duplicate group variable '{key}' in group '{group_name}'",
                    )
                )

    for host_name, host in project.hosts.items():
        seen: dict[str, int] = defaultdict(int)
        for variable in host.variables:
            seen[variable.key] += 1
        for key, count in seen.items():
            if count > 1:
                issues.append(
                    Issue(
                        severity=IssueSeverity.B,
                        message=f"Duplicate host variable '{key}' on host '{host_name}'",
                    )
                )

    return issues
EOF

cat > inventory_editor/tests/test_conflicts.py <<'EOF'
from inventory_editor.analyzer.conflicts import find_conflicts
from inventory_editor.models.project import ProjectModel
from inventory_editor.models.variable import Variable, VariableScope, VariableSource


def test_duplicate_host_variable_conflict():
    model = ProjectModel(root_path=".")

    var1 = Variable(
        key="app_env",
        value="prod",
        scope=VariableScope.HOST,
        owner="web01",
        source=VariableSource(
            source_path="host_vars/web01/main.yml",
            source_type="host_vars",
        ),
    )

    var2 = Variable(
        key="app_env",
        value="stage",
        scope=VariableScope.HOST,
        owner="web01",
        source=VariableSource(
            source_path="host_vars/web01/nginx.yml",
            source_type="host_vars",
        ),
    )

    model.add_variable_to_host("web01", var1)
    model.add_variable_to_host("web01", var2)

    issues = find_conflicts(model)

    assert len(issues) == 1
    assert issues[0].severity.value == "B"
EOF

echo "RELEASE-0007 applied"
