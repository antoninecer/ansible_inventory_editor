#!/usr/bin/env bash
set -e

cat > inventory_editor/models/variable.py <<'EOF'
from dataclasses import dataclass
from enum import Enum


class VariableScope(str, Enum):
    ALL = "all"
    GROUP = "group"
    HOST = "host"


@dataclass(slots=True)
class VariableSource:
    source_path: str
    source_type: str


@dataclass(slots=True)
class Variable:
    key: str
    value: object

    scope: VariableScope

    owner: str

    source: VariableSource
EOF

cat > inventory_editor/tests/test_variable.py <<'EOF'
from inventory_editor.models.variable import (
    Variable,
    VariableScope,
    VariableSource,
)


def test_variable_creation():
    variable = Variable(
        key="http_port",
        value=8080,
        scope=VariableScope.HOST,
        owner="web01",
        source=VariableSource(
            source_path="host_vars/web01/main.yml",
            source_type="host_vars",
        ),
    )

    assert variable.key == "http_port"
    assert variable.owner == "web01"
    assert variable.scope == VariableScope.HOST
EOF

echo "RELEASE-0004 applied"
