#!/usr/bin/env bash
set -e

cat > inventory_editor/models/project.py <<'EOF'
from collections import defaultdict
from dataclasses import dataclass, field
from heapq import heappop, heappush

from inventory_editor.models.group import Group
from inventory_editor.models.host import Host
from inventory_editor.models.variable import Variable, VariableScope


@dataclass(slots=True)
class ProjectModel:
    root_path: str
    inventory_file: str = "inventory.yml"

    groups: dict[str, Group] = field(default_factory=dict)
    hosts: dict[str, Host] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if "all" not in self.groups:
            self.groups["all"] = Group(name="all")

    def add_group(self, group_name: str) -> Group:
        if group_name in self.groups:
            return self.groups[group_name]

        group = Group(name=group_name)
        self.groups[group_name] = group
        return group

    def add_host(self, host_name: str) -> Host:
        if host_name in self.hosts:
            return self.hosts[host_name]

        host = Host(name=host_name)
        self.hosts[host_name] = host
        return host

    def assign_host_to_group(self, host_name: str, group_name: str) -> None:
        host = self.add_host(host_name)
        group = self.add_group(group_name)

        host.add_group(group_name)
        group.add_host(host_name)

    def add_variable_to_group(self, group_name: str, variable: Variable) -> None:
        group = self.add_group(group_name)
        if variable.scope != VariableScope.GROUP:
            raise ValueError("Variable scope must be GROUP for group variables")
        group.add_variable(variable)

    def add_variable_to_host(self, host_name: str, variable: Variable) -> None:
        host = self.add_host(host_name)
        if variable.scope != VariableScope.HOST:
            raise ValueError("Variable scope must be HOST for host variables")
        host.add_variable(variable)

    def _ancestor_group_names(self, group_name: str, seen: set[str] | None = None) -> set[str]:
        if seen is None:
            seen = set()

        for candidate_name, candidate_group in self.groups.items():
            if group_name in candidate_group.children and candidate_name not in seen:
                seen.add(candidate_name)
                self._ancestor_group_names(candidate_name, seen)

        return seen

    def ordered_groups_for_host(self, host_name: str) -> list[Group]:
        if host_name not in self.hosts:
            raise KeyError(f"Unknown host: {host_name}")

        host = self.hosts[host_name]
        applicable: set[str] = set()

        if "all" in self.groups:
            applicable.add("all")

        for direct_group in host.groups:
            applicable.add(direct_group)
            applicable.update(self._ancestor_group_names(direct_group))

        indegree: dict[str, int] = {name: 0 for name in applicable}
        children_map: dict[str, set[str]] = defaultdict(set)

        for parent_name, parent_group in self.groups.items():
            if parent_name not in applicable:
                continue

            for child_name in parent_group.children:
                if child_name in applicable and child_name != parent_name:
                    if child_name not in children_map[parent_name]:
                        children_map[parent_name].add(child_name)
                        indegree[child_name] += 1

        heap: list[str] = []
        for name, degree in indegree.items():
            if degree == 0:
                heappush(heap, name)

        ordered_names: list[str] = []
        seen: set[str] = set()

        while heap:
            name = heappop(heap)
            if name in seen:
                continue
            seen.add(name)
            ordered_names.append(name)

            for child_name in sorted(children_map.get(name, set())):
                indegree[child_name] -= 1
                if indegree[child_name] == 0:
                    heappush(heap, child_name)

        for name in sorted(applicable):
            if name not in seen and name in self.groups:
                ordered_names.append(name)

        return [self.groups[name] for name in ordered_names if name in self.groups]

    def effective_variables_for_host(self, host_name: str) -> dict[str, Variable]:
        if host_name not in self.hosts:
            raise KeyError(f"Unknown host: {host_name}")

        host = self.hosts[host_name]
        merged: dict[str, Variable] = {}

        for group in self.ordered_groups_for_host(host_name):
            for variable in group.variables:
                merged[variable.key] = variable

        for variable in host.variables:
            merged[variable.key] = variable

        return merged

    def group_count(self) -> int:
        return len(self.groups)

    def host_count(self) -> int:
        return len(self.hosts)
EOF

cat > inventory_editor/analyzer/tracing.py <<'EOF'
from dataclasses import dataclass

from inventory_editor.models.project import ProjectModel
from inventory_editor.models.variable import Variable


@dataclass(slots=True)
class TracedVariable:
    key: str
    effective: Variable
    sources: list[Variable]
    overridden_by: list[Variable]


def trace_variables_for_host(project: ProjectModel, host_name: str) -> list[TracedVariable]:
    if host_name not in project.hosts:
        raise KeyError(f"Unknown host: {host_name}")

    host = project.hosts[host_name]
    traced: dict[str, TracedVariable] = {}

    for group in project.ordered_groups_for_host(host_name):
        for variable in group.variables:
            if variable.key in traced:
                traced[variable.key].overridden_by.append(variable)
                traced[variable.key].effective = variable
                traced[variable.key].sources.append(variable)
            else:
                traced[variable.key] = TracedVariable(
                    key=variable.key,
                    effective=variable,
                    sources=[variable],
                    overridden_by=[],
                )

    for variable in host.variables:
        if variable.key in traced:
            traced[variable.key].overridden_by.append(variable)
            traced[variable.key].effective = variable
            traced[variable.key].sources.append(variable)
        else:
            traced[variable.key] = TracedVariable(
                key=variable.key,
                effective=variable,
                sources=[variable],
                overridden_by=[],
            )

    return list(traced.values())
EOF

cat > inventory_editor/tests/test_parent_child_precedence.py <<'EOF'
from inventory_editor.models.project import ProjectModel
from inventory_editor.models.variable import Variable, VariableScope, VariableSource


def test_parent_group_overridden_by_child_group():
    model = ProjectModel(root_path=".")

    model.add_variable_to_group(
        "all",
        Variable(
            key="http_port",
            value=80,
            scope=VariableScope.GROUP,
            owner="all",
            source=VariableSource(
                source_path="group_vars/all/main.yml",
                source_type="group_vars",
            ),
        ),
    )

    model.add_variable_to_group(
        "parent",
        Variable(
            key="http_port",
            value=81,
            scope=VariableScope.GROUP,
            owner="parent",
            source=VariableSource(
                source_path="group_vars/parent/main.yml",
                source_type="group_vars",
            ),
        ),
    )

    model.add_variable_to_group(
        "child",
        Variable(
            key="http_port",
            value=82,
            scope=VariableScope.GROUP,
            owner="child",
            source=VariableSource(
                source_path="group_vars/child/main.yml",
                source_type="group_vars",
            ),
        ),
    )

    model.groups["parent"].add_child("child")
    model.assign_host_to_group("web01", "child")

    effective = model.effective_variables_for_host("web01")

    assert effective["http_port"].value == 82
    assert effective["http_port"].source.source_path == "group_vars/child/main.yml"
EOF

echo "RELEASE-0021 applied"
