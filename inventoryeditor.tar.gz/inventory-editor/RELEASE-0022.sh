#!/usr/bin/env bash
set -e

mkdir -p inventory_editor/gui
mkdir -p inventory_editor/tests

cat > inventory_editor/gui/presenter.py <<'EOF'
from __future__ import annotations

from dataclasses import dataclass, field

from inventory_editor.analyzer.workspace_quality import WorkspaceQualityReport
from inventory_editor.models.project import ProjectModel
from inventory_editor.models.workspace import WorkspaceScanResult


@dataclass(slots=True)
class GroupCard:
    name: str
    hosts: list[str] = field(default_factory=list)
    children: list[str] = field(default_factory=list)
    variables: list[str] = field(default_factory=list)


@dataclass(slots=True)
class HostCard:
    name: str
    groups: list[str] = field(default_factory=list)
    variables: list[str] = field(default_factory=list)


@dataclass(slots=True)
class WorkspaceOverview:
    stats: list[tuple[str, str]] = field(default_factory=list)
    groups: list[GroupCard] = field(default_factory=list)
    hosts: list[HostCard] = field(default_factory=list)
    inventory_files: list[str] = field(default_factory=list)
    group_var_files: list[str] = field(default_factory=list)
    host_var_files: list[str] = field(default_factory=list)
    vault_files: list[str] = field(default_factory=list)
    backup_files: list[str] = field(default_factory=list)
    unknown_files: list[str] = field(default_factory=list)
    issues: list[str] = field(default_factory=list)


def build_workspace_overview(
    project: ProjectModel,
    scan: WorkspaceScanResult,
    report: WorkspaceQualityReport,
) -> WorkspaceOverview:
    overview = WorkspaceOverview()

    overview.stats = [
        ("Root", project.root_path),
        ("Inventory file", project.inventory_file),
        ("Groups", str(project.group_count())),
        ("Hosts", str(project.host_count())),
        ("Inventory files", str(len(scan.inventory_files))),
        ("Group var files", str(len(scan.group_var_paths))),
        ("Host var files", str(len(scan.host_var_paths))),
        ("Vault files", str(len(scan.vault_files))),
        ("Backup files", str(len(scan.backup_files))),
        ("Unknown files", str(len(scan.unknown_paths))),
    ]

    for group_name in sorted(project.groups):
        group = project.groups[group_name]
        overview.groups.append(
            GroupCard(
                name=group_name,
                hosts=sorted(group.hosts),
                children=sorted(group.children),
                variables=[f"{variable.key} = {variable.value}" for variable in group.variables],
            )
        )

    for host_name in sorted(project.hosts):
        host = project.hosts[host_name]
        overview.hosts.append(
            HostCard(
                name=host_name,
                groups=sorted(host.groups),
                variables=[f"{variable.key} = {variable.value}" for variable in host.variables],
            )
        )

    overview.inventory_files = list(scan.inventory_files)
    overview.group_var_files = list(scan.group_var_paths)
    overview.host_var_files = list(scan.host_var_paths)
    overview.vault_files = list(scan.vault_files)
    overview.backup_files = list(scan.backup_files)
    overview.unknown_files = list(scan.unknown_paths)
    overview.issues = [f"[{issue.severity.value}] {issue.message}" for issue in report.issues]

    return overview
EOF

cat > inventory_editor/gui/main_window.py <<'EOF'
from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QSplitter,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
    QWidget,
    QTextEdit,
)

from inventory_editor.analyzer.workspace_quality import analyze_workspace_scan
from inventory_editor.gui.presenter import build_workspace_overview
from inventory_editor.io.workspace_loader import load_inventory_workspace


class MainWindow(QMainWindow):
    def __init__(self, workspace: str | Path | None = None) -> None:
        super().__init__()
        self.setWindowTitle("Inventory Editor")
        self.resize(1400, 900)

        self._workspace_path = Path(workspace).expanduser().resolve() if workspace else None
        self._project = None
        self._scan = None
        self._report = None
        self._overview = None

        self.path_edit = QLineEdit()
        self.path_edit.setPlaceholderText("Workspace path")
        if self._workspace_path is not None:
            self.path_edit.setText(str(self._workspace_path))

        browse_button = QPushButton("Browse")
        load_button = QPushButton("Load")

        browse_button.clicked.connect(self._browse_workspace)
        load_button.clicked.connect(self._load_workspace)

        top_row = QHBoxLayout()
        top_row.addWidget(QLabel("Workspace:"))
        top_row.addWidget(self.path_edit, 1)
        top_row.addWidget(browse_button)
        top_row.addWidget(load_button)

        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["Name", "Type"])
        self.tree.itemSelectionChanged.connect(self._show_selected_item_details)

        self.details = QTextEdit()
        self.details.setReadOnly(True)

        splitter = QSplitter()
        splitter.addWidget(self.tree)
        splitter.addWidget(self.details)
        splitter.setStretchFactor(0, 2)
        splitter.setStretchFactor(1, 3)

        central = QWidget()
        layout = QVBoxLayout(central)
        layout.addLayout(top_row)
        layout.addWidget(splitter, 1)
        self.setCentralWidget(central)

        if self._workspace_path is not None:
            self._load_workspace()

    def _browse_workspace(self) -> None:
        selected = QFileDialog.getExistingDirectory(self, "Select inventory workspace")
        if selected:
            self.path_edit.setText(selected)
            self._load_workspace()

    def _load_workspace(self) -> None:
        raw_path = self.path_edit.text().strip()
        if not raw_path:
            QMessageBox.warning(self, "Missing workspace", "Enter a workspace path first.")
            return

        try:
            project, scan = load_inventory_workspace(raw_path)
            report = analyze_workspace_scan(scan)
            overview = build_workspace_overview(project, scan, report)
        except Exception as exc:  # pragma: no cover - UI error path
            QMessageBox.critical(self, "Load failed", str(exc))
            self.details.setPlainText(str(exc))
            return

        self._project = project
        self._scan = scan
        self._report = report
        self._overview = overview

        self._rebuild_tree()
        self._show_overview()

    def _rebuild_tree(self) -> None:
        self.tree.clear()
        if self._overview is None:
            return

        root = QTreeWidgetItem(["Workspace", "root"])
        root.setData(0, Qt.ItemDataRole.UserRole, "workspace")
        self.tree.addTopLevelItem(root)

        summary = QTreeWidgetItem(["Summary", "stats"])
        summary.setData(0, Qt.ItemDataRole.UserRole, "summary")
        root.addChild(summary)

        for label, value in self._overview.stats:
            item = QTreeWidgetItem([label, value])
            item.setData(0, Qt.ItemDataRole.UserRole, f"{label}: {value}")
            summary.addChild(item)

        groups = QTreeWidgetItem(["Groups", str(len(self._overview.groups))])
        groups.setData(0, Qt.ItemDataRole.UserRole, "groups")
        root.addChild(groups)
        for card in self._overview.groups:
            item = QTreeWidgetItem([card.name, f"hosts={len(card.hosts)} vars={len(card.variables)}"])
            item.setData(
                0,
                Qt.ItemDataRole.UserRole,
                "\n".join(
                    [
                        f"Group: {card.name}",
                        f"Hosts: {', '.join(card.hosts) if card.hosts else '-'}",
                        f"Children: {', '.join(card.children) if card.children else '-'}",
                        f"Variables: {', '.join(card.variables) if card.variables else '-'}",
                    ]
                ),
            )
            groups.addChild(item)

        hosts = QTreeWidgetItem(["Hosts", str(len(self._overview.hosts))])
        hosts.setData(0, Qt.ItemDataRole.UserRole, "hosts")
        root.addChild(hosts)
        for card in self._overview.hosts:
            item = QTreeWidgetItem([card.name, f"groups={len(card.groups)} vars={len(card.variables)}"])
            item.setData(
                0,
                Qt.ItemDataRole.UserRole,
                "\n".join(
                    [
                        f"Host: {card.name}",
                        f"Groups: {', '.join(card.groups) if card.groups else '-'}",
                        f"Variables: {', '.join(card.variables) if card.variables else '-'}",
                    ]
                ),
            )
            hosts.addChild(item)

        files = QTreeWidgetItem(["Files", "workspace files"])
        files.setData(0, Qt.ItemDataRole.UserRole, "files")
        root.addChild(files)

        sections = [
            ("Inventory files", self._overview.inventory_files),
            ("Group var files", self._overview.group_var_files),
            ("Host var files", self._overview.host_var_files),
            ("Vault files", self._overview.vault_files),
            ("Backup files", self._overview.backup_files),
            ("Unknown files", self._overview.unknown_files),
        ]
        for section_name, values in sections:
            section = QTreeWidgetItem([section_name, str(len(values))])
            section.setData(
                0,
                Qt.ItemDataRole.UserRole,
                "\n".join([section_name] + (values if values else ["-"])),
            )
            files.addChild(section)
            for value in values:
                child = QTreeWidgetItem([value, "file"])
                child.setData(0, Qt.ItemDataRole.UserRole, value)
                section.addChild(child)

        issues = QTreeWidgetItem(["Issues", str(len(self._overview.issues))])
        issues.setData(0, Qt.ItemDataRole.UserRole, "issues")
        root.addChild(issues)
        if self._overview.issues:
            for issue in self._overview.issues:
                child = QTreeWidgetItem([issue, "issue"])
                child.setData(0, Qt.ItemDataRole.UserRole, issue)
                issues.addChild(child)
        else:
            child = QTreeWidgetItem(["No issues", "ok"])
            child.setData(0, Qt.ItemDataRole.UserRole, "No issues")
            issues.addChild(child)

        self.tree.expandAll()

    def _show_overview(self) -> None:
        if self._overview is None:
            self.details.setPlainText("No workspace loaded.")
            return

        lines = ["Workspace overview", ""]
        for label, value in self._overview.stats:
            lines.append(f"{label}: {value}")
        self.details.setPlainText("\n".join(lines))

    def _show_selected_item_details(self) -> None:
        items = self.tree.selectedItems()
        if not items:
            self._show_overview()
            return

        item = items[0]
        payload = item.data(0, Qt.ItemDataRole.UserRole)
        if payload:
            self.details.setPlainText(str(payload))
        else:
            self.details.setPlainText(f"{item.text(0)}")
EOF

cat > inventory_editor/gui/app.py <<'EOF'
from __future__ import annotations

import sys
from pathlib import Path

from PySide6.QtWidgets import QApplication

from inventory_editor.gui.main_window import MainWindow


def main(argv: list[str] | None = None) -> int:
    args = list(sys.argv[1:] if argv is None else argv)

    workspace = Path(args[0]).expanduser().resolve() if args else None

    app = QApplication(sys.argv[:1])
    window = MainWindow(workspace=workspace)
    window.show()
    return app.exec()
EOF

cat > inventory_editor/gui/__main__.py <<'EOF'
from inventory_editor.gui.app import main

raise SystemExit(main())
EOF

cat > inventory_editor/tests/test_gui_presenter.py <<'EOF'
from inventory_editor.analyzer.issues import Issue, IssueSeverity
from inventory_editor.analyzer.workspace_quality import WorkspaceQualityReport
from inventory_editor.gui.presenter import build_workspace_overview
from inventory_editor.models.project import ProjectModel
from inventory_editor.models.variable import Variable, VariableScope, VariableSource
from inventory_editor.models.workspace import WorkspaceScanResult


def test_build_workspace_overview():
    project = ProjectModel(root_path=".")
    project.add_variable_to_group(
        "all",
        Variable(
            key="debug",
            value=True,
            scope=VariableScope.GROUP,
            owner="all",
            source=VariableSource(
                source_path="group_vars/all/main.yml",
                source_type="group_vars",
            ),
        ),
    )
    project.assign_host_to_group("web01", "web")
    project.add_variable_to_host(
        "web01",
        Variable(
            key="http_port",
            value=8080,
            scope=VariableScope.HOST,
            owner="web01",
            source=VariableSource(
                source_path="host_vars/web01/main.yml",
                source_type="host_vars",
            ),
        ),
    )

    scan = WorkspaceScanResult(
        root_path="/tmp/inventory",
        inventory_files=["inventory.yml"],
        group_var_paths=["group_vars/all/main.yml"],
        host_var_paths=["host_vars/web01/main.yml"],
        vault_files=["group_vars/web/vault.yml"],
        backup_files=["inventory.yml-20240522"],
        unknown_paths=["notes.txt"],
    )
    report = WorkspaceQualityReport(
        issues=[Issue(severity=IssueSeverity.C, message="Unknown file", source_path="notes.txt")]
    )

    overview = build_workspace_overview(project, scan, report)

    assert ("Groups", "2") in overview.stats
    assert ("Hosts", "1") in overview.stats
    assert overview.groups[0].name == "all"
    assert "debug = True" in overview.groups[0].variables
    assert "http_port = 8080" in overview.hosts[0].variables
    assert "[C] Unknown file" in overview.issues[0]
EOF

echo "RELEASE-0022 applied"
