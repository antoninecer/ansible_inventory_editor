#!/usr/bin/env bash
set -e

cat > inventory_editor/analyzer/host_search.py <<'EOF'
from dataclasses import dataclass

from inventory_editor.models.project import ProjectModel


@dataclass(slots=True)
class HostSearchResult:
    host_name: str
    groups: list[str]
    host_vars: list[str]
    group_vars: list[str]


def find_hosts(project: ProjectModel, query: str) -> list[HostSearchResult]:
    term = query.strip().lower()
    if not term:
        return []

    results: list[HostSearchResult] = []

    for host_name in sorted(project.hosts):
        if term not in host_name.lower():
            continue

        host = project.hosts[host_name]
        groups = sorted(host.groups)

        group_vars: list[str] = []
        for group_name in groups:
            group = project.groups.get(group_name)
            if group is None:
                continue
            for variable in group.variables:
                group_vars.append(f"{group_name}:{variable.key}")

        host_vars = [variable.key for variable in host.variables]

        results.append(
            HostSearchResult(
                host_name=host_name,
                groups=groups,
                host_vars=host_vars,
                group_vars=group_vars,
            )
        )

    return results


def describe_host(project: ProjectModel, host_name: str) -> str:
    if host_name not in project.hosts:
        return f"Host '{host_name}' not found"

    host = project.hosts[host_name]
    lines = [
        f"Host: {host_name}",
        f"Groups: {', '.join(sorted(host.groups)) if host.groups else '-'}",
        f"Host variables: {', '.join(variable.key for variable in host.variables) if host.variables else '-'}",
    ]

    if host.groups:
        lines.append("Group variables:")
        for group_name in sorted(host.groups):
            group = project.groups.get(group_name)
            if group is None:
                continue
            if not group.variables:
                lines.append(f"  - {group_name}: -")
                continue
            for variable in group.variables:
                lines.append(f"  - {group_name}: {variable.key}")

    return "\n".join(lines)
EOF

cat > inventory_editor/tests/test_host_search.py <<'EOF'
from inventory_editor.analyzer.host_search import describe_host, find_hosts
from inventory_editor.models.project import ProjectModel
from inventory_editor.models.variable import Variable, VariableScope, VariableSource


def test_find_hosts_by_partial_name():
    model = ProjectModel(root_path=".")
    model.add_host("web01")
    model.add_host("db01")

    results = find_hosts(model, "web")

    assert len(results) == 1
    assert results[0].host_name == "web01"


def test_describe_host():
    model = ProjectModel(root_path=".")
    model.add_variable_to_group(
        "web",
        Variable(
            key="http_port",
            value=80,
            scope=VariableScope.GROUP,
            owner="web",
            source=VariableSource(
                source_path="group_vars/web/main.yml",
                source_type="group_vars",
            ),
        ),
    )
    model.assign_host_to_group("web01", "web")
    model.add_variable_to_host(
        "web01",
        Variable(
            key="nginx_port",
            value=8080,
            scope=VariableScope.HOST,
            owner="web01",
            source=VariableSource(
                source_path="host_vars/web01/main.yml",
                source_type="host_vars",
            ),
        ),
    )

    text = describe_host(model, "web01")

    assert "Host: web01" in text
    assert "Groups: web" in text
    assert "http_port" in text
    assert "nginx_port" in text
EOF

echo "RELEASE-0026 applied"
