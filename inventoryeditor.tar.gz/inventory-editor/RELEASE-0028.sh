#!/usr/bin/env bash
set -e

cat > inventory_editor/models/project.py <<'EOF'
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from heapq import heappop, heappush

from inventory_editor.models.group import Group
from inventory_editor.models.host import Host
from inventory_editor.models.variable import Variable, VariableScope


@dataclass(slots=True)
class ProjectModel:
    root_path: str
    inventory_file: str = "inventory.yml"

    groups: dict[str, Group] = field(default_factory=dict)
    hosts: dict[str, Host] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if "all" not in self.groups:
            self.groups["all"] = Group(name="all")

    def add_group(self, group_name: str) -> Group:
        if group_name in self.groups:
            return self.groups[group_name]

        group = Group(name=group_name)
        self.groups[group_name] = group
        return group

    def add_host(self, host_name: str) -> Host:
        if host_name in self.hosts:
            return self.hosts[host_name]

        host = Host(name=host_name)
        self.hosts[host_name] = host
        return host

    def assign_host_to_group(self, host_name: str, group_name: str) -> None:
        host = self.add_host(host_name)
        group = self.add_group(group_name)

        host.add_group(group_name)
        group.add_host(host_name)

    def add_variable_to_group(self, group_name: str, variable: Variable) -> None:
        group = self.add_group(group_name)
        if variable.scope != VariableScope.GROUP:
            raise ValueError("Variable scope must be GROUP for group variables")
        group.add_variable(variable)

    def add_variable_to_host(self, host_name: str, variable: Variable) -> None:
        host = self.add_host(host_name)
        if variable.scope != VariableScope.HOST:
            raise ValueError("Variable scope must be HOST for host variables")
        host.add_variable(variable)

    def replace_variable_in_group(self, group_name: str, variable: Variable) -> None:
        group = self.add_group(group_name)
        if variable.scope != VariableScope.GROUP:
            raise ValueError("Variable scope must be GROUP for group variables")
        group.variables = [item for item in group.variables if item.key != variable.key]
        group.add_variable(variable)

    def replace_variable_in_host(self, host_name: str, variable: Variable) -> None:
        host = self.add_host(host_name)
        if variable.scope != VariableScope.HOST:
            raise ValueError("Variable scope must be HOST for host variables")
        host.variables = [item for item in host.variables if item.key != variable.key]
        host.add_variable(variable)

    def parent_groups_for_group(self, group_name: str) -> list[str]:
        parents: list[str] = []
        for candidate_name, candidate_group in self.groups.items():
            if group_name in candidate_group.children:
                parents.append(candidate_name)
        return sorted(parents)

    def ancestor_chain_for_group(self, group_name: str) -> list[str]:
        if group_name not in self.groups:
            return []

        ordered: list[str] = []
        seen: set[str] = set()

        def visit(name: str) -> None:
            for parent in self.parent_groups_for_group(name):
                if parent in seen:
                    continue
                visit(parent)
                if parent not in seen:
                    seen.add(parent)
                    ordered.append(parent)

        visit(group_name)
        return ordered

    def branch_groups_for_context(self, branch_group_name: str | None) -> list[str]:
        if branch_group_name in (None, "", "ungrouped"):
            return ["all"] if "all" in self.groups else []

        if branch_group_name == "all":
            return ["all"]

        ordered: list[str] = []
        if "all" in self.groups:
            ordered.append("all")

        for ancestor in self.ancestor_chain_for_group(branch_group_name):
            if ancestor not in ordered:
                ordered.append(ancestor)

        if branch_group_name not in ordered:
            ordered.append(branch_group_name)

        return ordered

    def ordered_groups_for_host(self, host_name: str) -> list[Group]:
        if host_name not in self.hosts:
            raise KeyError(f"Unknown host: {host_name}")

        host = self.hosts[host_name]
        applicable: set[str] = set()

        if "all" in self.groups:
            applicable.add("all")

        for direct_group in host.groups:
            applicable.add(direct_group)
            applicable.update(self.ancestor_chain_for_group(direct_group))

        indegree: dict[str, int] = {name: 0 for name in applicable}
        children_map: dict[str, set[str]] = defaultdict(set)

        for parent_name, parent_group in self.groups.items():
            if parent_name not in applicable:
                continue

            for child_name in parent_group.children:
                if child_name in applicable and child_name != parent_name:
                    if child_name not in children_map[parent_name]:
                        children_map[parent_name].add(child_name)
                        indegree[child_name] += 1

        heap: list[str] = []
        for name, degree in indegree.items():
            if degree == 0:
                heappush(heap, name)

        ordered_names: list[str] = []
        seen: set[str] = set()

        while heap:
            name = heappop(heap)
            if name in seen:
                continue
            seen.add(name)
            ordered_names.append(name)

            for child_name in sorted(children_map.get(name, set())):
                indegree[child_name] -= 1
                if indegree[child_name] == 0:
                    heappush(heap, child_name)

        for name in sorted(applicable):
            if name not in seen and name in self.groups:
                ordered_names.append(name)

        return [self.groups[name] for name in ordered_names if name in self.groups]

    def effective_variables_for_host(self, host_name: str) -> dict[str, Variable]:
        if host_name not in self.hosts:
            raise KeyError(f"Unknown host: {host_name}")

        host = self.hosts[host_name]
        merged: dict[str, Variable] = {}

        for group in self.ordered_groups_for_host(host_name):
            for variable in group.variables:
                merged[variable.key] = variable

        for variable in host.variables:
            merged[variable.key] = variable

        return merged

    def effective_variables_for_branch(self, host_name: str, branch_group_name: str | None) -> dict[str, Variable]:
        if host_name not in self.hosts:
            raise KeyError(f"Unknown host: {host_name}")

        host = self.hosts[host_name]
        merged: dict[str, Variable] = {}

        for group_name in self.branch_groups_for_context(branch_group_name):
            group = self.groups.get(group_name)
            if group is None:
                continue
            for variable in group.variables:
                merged[variable.key] = variable

        for variable in host.variables:
            merged[variable.key] = variable

        return merged

    def group_count(self) -> int:
        return len(self.groups)

    def host_count(self) -> int:
        return len(self.hosts)
EOF

cat > inventory_editor/analyzer/tracing.py <<'EOF'
from __future__ import annotations

from dataclasses import dataclass

from inventory_editor.models.project import ProjectModel
from inventory_editor.models.variable import Variable


@dataclass(slots=True)
class TracedVariable:
    key: str
    effective: Variable
    sources: list[Variable]
    overridden_by: list[Variable]


def trace_variables_for_host(project: ProjectModel, host_name: str) -> list[TracedVariable]:
    if host_name not in project.hosts:
        raise KeyError(f"Unknown host: {host_name}")

    host = project.hosts[host_name]
    traced: dict[str, TracedVariable] = {}

    for group in project.ordered_groups_for_host(host_name):
        for variable in group.variables:
            if variable.key in traced:
                traced[variable.key].overridden_by.append(variable)
                traced[variable.key].effective = variable
                traced[variable.key].sources.append(variable)
            else:
                traced[variable.key] = TracedVariable(
                    key=variable.key,
                    effective=variable,
                    sources=[variable],
                    overridden_by=[],
                )

    for variable in host.variables:
        if variable.key in traced:
            traced[variable.key].overridden_by.append(variable)
            traced[variable.key].effective = variable
            traced[variable.key].sources.append(variable)
        else:
            traced[variable.key] = TracedVariable(
                key=variable.key,
                effective=variable,
                sources=[variable],
                overridden_by=[],
            )

    return list(traced.values())


def trace_variables_for_branch(project: ProjectModel, host_name: str, branch_group_name: str | None) -> list[TracedVariable]:
    if host_name not in project.hosts:
        raise KeyError(f"Unknown host: {host_name}")

    host = project.hosts[host_name]
    traced: dict[str, TracedVariable] = {}

    for group_name in project.branch_groups_for_context(branch_group_name):
        group = project.groups.get(group_name)
        if group is None:
            continue

        for variable in group.variables:
            if variable.key in traced:
                traced[variable.key].overridden_by.append(variable)
                traced[variable.key].effective = variable
                traced[variable.key].sources.append(variable)
            else:
                traced[variable.key] = TracedVariable(
                    key=variable.key,
                    effective=variable,
                    sources=[variable],
                    overridden_by=[],
                )

    for variable in host.variables:
        if variable.key in traced:
            traced[variable.key].overridden_by.append(variable)
            traced[variable.key].effective = variable
            traced[variable.key].sources.append(variable)
        else:
            traced[variable.key] = TracedVariable(
                key=variable.key,
                effective=variable,
                sources=[variable],
                overridden_by=[],
            )

    return list(traced.values())
EOF

cat > inventory_editor/analyzer/reporting.py <<'EOF'
from __future__ import annotations

from inventory_editor.analyzer.tracing import trace_variables_for_branch, trace_variables_for_host
from inventory_editor.models.project import ProjectModel


def explain_variable_for_host(project: ProjectModel, host_name: str, key: str) -> str:
    traced = trace_variables_for_host(project, host_name)

    for item in traced:
        if item.key != key:
            continue

        lines = [
            f"Host: {host_name}",
            f"Variable: {key}",
            f"Effective value: {item.effective.value}",
            f"Effective source: {item.effective.source.source_path}",
            "Trace:",
        ]

        for variable in item.sources:
            lines.append(f"  - {variable.source.source_path}: {variable.value}")

        if item.overridden_by:
            lines.append("Overridden by:")
            for variable in item.overridden_by:
                lines.append(f"  - {variable.source.source_path}: {variable.value}")

        return "\n".join(lines)

    return f"Variable '{key}' not found for host '{host_name}'"


def explain_variable_for_branch(project: ProjectModel, host_name: str, branch_group_name: str | None, key: str) -> str:
    traced = trace_variables_for_branch(project, host_name, branch_group_name)

    for item in traced:
        if item.key != key:
            continue

        branch_label = branch_group_name if branch_group_name not in (None, "", "ungrouped") else "ungrouped"
        lines = [
            f"Host: {host_name}",
            f"Branch: {branch_label}",
            f"Variable: {key}",
            f"Effective value: {item.effective.value}",
            f"Effective source: {item.effective.source.source_path}",
            "Trace:",
        ]

        for variable in item.sources:
            lines.append(f"  - {variable.source.source_path}: {variable.value}")

        if item.overridden_by:
            lines.append("Overridden by:")
            for variable in item.overridden_by:
                lines.append(f"  - {variable.source.source_path}: {variable.value}")

        return "\n".join(lines)

    return f"Variable '{key}' not found for host '{host_name}' in branch '{branch_group_name}'"
EOF

cat > inventory_editor/gui/context.py <<'EOF'
from __future__ import annotations

from dataclasses import dataclass, field

from inventory_editor.analyzer.reporting import explain_variable_for_branch
from inventory_editor.analyzer.tracing import trace_variables_for_branch
from inventory_editor.models.project import ProjectModel
from inventory_editor.models.variable import Variable
from inventory_editor.models.workspace import WorkspaceScanResult


def _value_text(value: object) -> str:
    return str(value)


def _scope_color(scope: str, source_path: str) -> str:
    path = source_path.lower()
    if "vault.yml" in path:
        return "#8e24aa"
    if scope == "host":
        return "#2e7d32"
    if scope == "group":
        if "group_vars/all/" in path:
            return "#546e7a"
        return "#1565c0"
    return "#546e7a"


def _file_color(kind: str) -> str:
    if kind == "vault":
        return "#8e24aa"
    if kind == "host-var":
        return "#2e7d32"
    if kind == "group-var":
        return "#1565c0"
    return "#546e7a"


def _kind_for_path(path: str) -> str:
    lower = path.lower()
    if "vault.yml" in lower:
        return "vault"
    if lower.startswith("host_vars/"):
        return "host-var"
    if lower.startswith("group_vars/"):
        return "group-var"
    if lower.endswith((".yml", ".yaml")):
        return "yaml"
    return "file"


def _add_unique_file(rows: list["ContextFileRow"], seen: set[str], path: str, kind: str) -> None:
    if not path or path in seen:
        return
    seen.add(path)
    rows.append(ContextFileRow(kind=kind, path=path, color=_file_color(kind)))


@dataclass(slots=True)
class ContextVariableRow:
    key: str
    value_text: str
    scope: str
    source_path: str
    source_type: str
    color: str


@dataclass(slots=True)
class ContextFileRow:
    kind: str
    path: str
    color: str


@dataclass(slots=True)
class GroupContextView:
    title: str
    summary_lines: list[str] = field(default_factory=list)
    hosts: list[str] = field(default_factory=list)
    children: list[str] = field(default_factory=list)
    variables: list[ContextVariableRow] = field(default_factory=list)
    files: list[ContextFileRow] = field(default_factory=list)


@dataclass(slots=True)
class HostContextView:
    title: str
    summary_lines: list[str] = field(default_factory=list)
    variables: list[ContextVariableRow] = field(default_factory=list)
    files: list[ContextFileRow] = field(default_factory=list)
    trace_map: dict[str, str] = field(default_factory=dict)


def build_group_context_view(project: ProjectModel, scan: WorkspaceScanResult, group_name: str) -> GroupContextView:
    if group_name == "ungrouped":
        hosts = sorted(host_name for host_name, host in project.hosts.items() if not host.groups)
        summary_lines = [
            "Group: ungrouped",
            f"Hosts: {len(hosts)}",
            "This is the fallback branch for hosts with no explicit group membership.",
        ]
        return GroupContextView(title="ungrouped", summary_lines=summary_lines, hosts=hosts)

    group = project.groups.get(group_name)
    if group is None:
        raise KeyError(f"Unknown group: {group_name}")

    summary_lines = [
        f"Group: {group_name}",
        f"Direct hosts: {len(group.hosts)}",
        f"Child groups: {len(group.children)}",
        f"Variables: {len(group.variables)}",
    ]

    variables: list[ContextVariableRow] = []
    files: list[ContextFileRow] = []
    seen_files: set[str] = set()

    for variable in group.variables:
        source_path = variable.source.source_path
        variables.append(
            ContextVariableRow(
                key=variable.key,
                value_text=_value_text(variable.value),
                scope=variable.scope.value,
                source_path=source_path,
                source_type=variable.source.source_type,
                color=_scope_color(variable.scope.value, source_path),
            )
        )
        _add_unique_file(files, seen_files, source_path, _kind_for_path(source_path))

    for path in scan.group_var_paths:
        if path.startswith(f"group_vars/{group_name}/"):
            _add_unique_file(files, seen_files, path, _kind_for_path(path))

    for path in scan.vault_files:
        if path.startswith(f"group_vars/{group_name}/"):
            _add_unique_file(files, seen_files, path, _kind_for_path(path))

    return GroupContextView(
        title=group_name,
        summary_lines=summary_lines,
        hosts=sorted(group.hosts),
        children=sorted(group.children),
        variables=variables,
        files=files,
    )


def build_host_context_view(
    project: ProjectModel,
    scan: WorkspaceScanResult,
    host_name: str,
    branch_group_name: str | None,
) -> HostContextView:
    host = project.hosts.get(host_name)
    if host is None:
        raise KeyError(f"Unknown host: {host_name}")

    branch_label = branch_group_name if branch_group_name not in (None, "", "ungrouped") else "ungrouped"
    branch_groups = project.branch_groups_for_context(branch_group_name)
    effective = project.effective_variables_for_branch(host_name, branch_group_name)
    traces = trace_variables_for_branch(project, host_name, branch_group_name)

    summary_lines = [
        f"Host: {host_name}",
        f"Branch: {branch_label}",
        f"Direct groups: {', '.join(sorted(host.groups)) if host.groups else '-'}",
        f"Context groups: {', '.join(branch_groups) if branch_groups else '-'}",
        f"Effective variables: {len(effective)}",
    ]

    variables: list[ContextVariableRow] = []
    for key, variable in sorted(effective.items(), key=lambda item: item[0].lower()):
        source_path = variable.source.source_path
        variables.append(
            ContextVariableRow(
                key=key,
                value_text=_value_text(variable.value),
                scope=variable.scope.value,
                source_path=source_path,
                source_type=variable.source.source_type,
                color=_scope_color(variable.scope.value, source_path),
            )
        )

    files: list[ContextFileRow] = []
    seen_files: set[str] = set()

    for group_name in branch_groups:
        group = project.groups.get(group_name)
        if group is None:
            continue
        for variable in group.variables:
            _add_unique_file(files, seen_files, variable.source.source_path, _kind_for_path(variable.source.source_path))

    for variable in host.variables:
        _add_unique_file(files, seen_files, variable.source.source_path, _kind_for_path(variable.source.source_path))

    for path in scan.group_var_paths:
        if any(path.startswith(f"group_vars/{group_name}/") for group_name in branch_groups):
            _add_unique_file(files, seen_files, path, _kind_for_path(path))

    for path in scan.host_var_paths:
        if path.startswith(f"host_vars/{host_name}/"):
            _add_unique_file(files, seen_files, path, _kind_for_path(path))

    for path in scan.vault_files:
        if path.startswith("group_vars/all/"):
            _add_unique_file(files, seen_files, path, _kind_for_path(path))
        elif any(path.startswith(f"group_vars/{group_name}/") for group_name in branch_groups if group_name != "all"):
            _add_unique_file(files, seen_files, path, _kind_for_path(path))
        elif path.startswith(f"host_vars/{host_name}/"):
            _add_unique_file(files, seen_files, path, _kind_for_path(path))

    trace_map = {
        item.key: explain_variable_for_branch(project, host_name, branch_group_name, item.key)
        for item in traces
    }

    return HostContextView(
        title=host_name,
        summary_lines=summary_lines,
        variables=variables,
        files=files,
        trace_map=trace_map,
    )
EOF

cat > inventory_editor/gui/main_window.py <<'EOF'
from __future__ import annotations

import os
import shlex
import subprocess
from pathlib import Path

from PySide6.QtCore import Qt, QUrl
from PySide6.QtGui import QColor, QDesktopServices, QBrush, QFont
from PySide6.QtWidgets import (
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QSplitter,
    QTabWidget,
    QTextEdit,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
    QWidget,
)

from ruamel.yaml import YAML

from inventory_editor.analyzer.workspace_quality import analyze_workspace_scan
from inventory_editor.gui.context import (
    build_group_context_view,
    build_host_context_view,
)
from inventory_editor.gui.presenter import build_workspace_overview
from inventory_editor.io.exporter import export_workspace if False else None
from inventory_editor.io.workspace_exporter import export_workspace
from inventory_editor.io.workspace_loader import load_inventory_workspace
from inventory_editor.models.project import ProjectModel
from inventory_editor.models.variable import Variable, VariableScope, VariableSource

_yaml_loader = YAML(typ="safe")


class VariableDialog(QDialog):
    def __init__(self, parent: QWidget, title: str, default_file: str = "main.yml") -> None:
        super().__init__(parent)
        self.setWindowTitle(title)
        self.resize(640, 420)

        self._value = None

        layout = QVBoxLayout(self)
        form = QFormLayout()

        self.key_edit = QLineEdit()
        self.file_edit = QLineEdit(default_file)
        self.value_edit = QTextEdit()
        self.value_edit.setPlaceholderText("YAML value, for example: 42, true, [a, b], or a multiline mapping")

        form.addRow("Key:", self.key_edit)
        form.addRow("File name:", self.file_edit)
        form.addRow("Value:", self.value_edit)

        layout.addLayout(form)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self._accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def _accept(self) -> None:
        key = self.key_edit.text().strip()
        if not key:
            QMessageBox.warning(self, "Missing key", "Variable key cannot be empty.", parent=self)
            return

        file_name = self.file_edit.text().strip() or "main.yml"
        if file_name.lower() == "vault.yml":
            QMessageBox.warning(
                self,
                "Vault editing not enabled",
                "Vault files are shown and can be opened, but editing vault content is not enabled in this release.",
                parent=self,
            )
            return

        raw_value = self.value_edit.toPlainText().strip()
        try:
            value = _yaml_loader.load(raw_value) if raw_value else None
        except Exception as exc:
            QMessageBox.warning(self, "Invalid value", f"YAML parsing failed: {exc}", parent=self)
            return

        self._value = (key, value, file_name)
        self.accept()

    @property
    def result_data(self) -> tuple[str, object, str] | None:
        return self._value


class MainWindow(QMainWindow):
    def __init__(self, workspace: str | Path | None = None) -> None:
        super().__init__()
        self.setWindowTitle("Inventory Editor")
        self.resize(1600, 980)
        self.statusBar().showMessage("Ready")

        self._workspace_path: Path | None = None
        self._project: ProjectModel | None = None
        self._scan = None
        self._report = None
        self._overview = None
        self._dirty = False

        self._current_mode: str | None = None
        self._current_group: str | None = None
        self._current_host: str | None = None
        self._current_branch_group: str | None = None
        self._current_file_path: str | None = None
        self._current_file_kind: str | None = None

        self.path_edit = QLineEdit()
        self.path_edit.setPlaceholderText("Workspace path")

        browse_button = QPushButton("Browse")
        load_button = QPushButton("Load")
        add_group_button = QPushButton("Add group")
        add_host_button = QPushButton("Add host")
        add_variable_button = QPushButton("Add variable")
        export_button = QPushButton("Export")

        browse_button.clicked.connect(self._browse_workspace)
        load_button.clicked.connect(self._load_workspace)
        add_group_button.clicked.connect(self._add_group)
        add_host_button.clicked.connect(self._add_host)
        add_variable_button.clicked.connect(self._add_variable)
        export_button.clicked.connect(self._export_workspace)

        top_row = QHBoxLayout()
        top_row.addWidget(QLabel("Workspace:"))
        top_row.addWidget(self.path_edit, 1)
        top_row.addWidget(browse_button)
        top_row.addWidget(load_button)
        top_row.addWidget(add_group_button)
        top_row.addWidget(add_host_button)
        top_row.addWidget(add_variable_button)
        top_row.addWidget(export_button)

        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["Name", "Type"])
        self.tree.itemSelectionChanged.connect(self._on_tree_selection_changed)
        self.tree.setMinimumWidth(420)

        self.tabs = QTabWidget()

        self.overview_text = QTextEdit()
        self.overview_text.setReadOnly(True)

        self.variables_tree = QTreeWidget()
        self.variables_tree.setHeaderLabels(["Key", "Value", "Scope", "Source"])
        self.variables_tree.itemSelectionChanged.connect(self._on_variable_selection_changed)

        self.trace_text = QTextEdit()
        self.trace_text.setReadOnly(True)

        variables_splitter = QSplitter(Qt.Orientation.Vertical)
        variables_splitter.addWidget(self.variables_tree)
        variables_splitter.addWidget(self.trace_text)
        variables_splitter.setStretchFactor(0, 3)
        variables_splitter.setStretchFactor(1, 2)

        self.files_tree = QTreeWidget()
        self.files_tree.setHeaderLabels(["Kind", "Path"])
        self.files_tree.itemSelectionChanged.connect(self._on_file_selection_changed)

        self.file_preview = QTextEdit()
        self.file_preview.setReadOnly(True)

        file_buttons = QHBoxLayout()
        self.open_source_button = QPushButton("Open source")
        self.edit_source_button = QPushButton("Edit source")
        self.open_source_button.clicked.connect(self._open_source)
        self.edit_source_button.clicked.connect(self._edit_source)
        file_buttons.addWidget(self.open_source_button)
        file_buttons.addWidget(self.edit_source_button)
        file_buttons.addStretch(1)

        files_container = QWidget()
        files_layout = QVBoxLayout(files_container)
        files_layout.addWidget(self.files_tree, 1)
        files_layout.addLayout(file_buttons)
        files_layout.addWidget(self.file_preview)

        self.issues_text = QTextEdit()
        self.issues_text.setReadOnly(True)

        self.tabs.addTab(self.overview_text, "Overview")
        self.tabs.addTab(variables_splitter, "Variables")
        self.tabs.addTab(files_container, "Files")
        self.tabs.addTab(self.issues_text, "Issues")

        splitter = QSplitter()
        splitter.addWidget(self.tree)
        splitter.addWidget(self.tabs)
        splitter.setStretchFactor(0, 2)
        splitter.setStretchFactor(1, 5)

        central = QWidget()
        layout = QVBoxLayout(central)
        layout.addLayout(top_row)
        layout.addWidget(splitter, 1)
        self.setCentralWidget(central)

        if workspace is not None:
            self.path_edit.setText(str(Path(workspace).expanduser().resolve()))
            self._load_workspace()

    def _browse_workspace(self) -> None:
        selected = QFileDialog.getExistingDirectory(self, "Select inventory workspace")
        if selected:
            self.path_edit.setText(selected)
            self._load_workspace()

    def _load_workspace(self) -> None:
        raw_path = self.path_edit.text().strip()
        if not raw_path:
            QMessageBox.warning(self, "Missing workspace", "Enter a workspace path first.", parent=self)
            return

        try:
            project, scan = load_inventory_workspace(raw_path)
            report = analyze_workspace_scan(scan)
            overview = build_workspace_overview(project, scan, report)
        except Exception as exc:  # pragma: no cover - UI error path
            QMessageBox.critical(self, "Load failed", str(exc), parent=self)
            self.file_preview.setPlainText(str(exc))
            return

        self._workspace_path = Path(raw_path).expanduser().resolve()
        self._project = project
        self._scan = scan
        self._report = report
        self._overview = overview
        self._dirty = False

        self._current_mode = None
        self._current_group = None
        self._current_host = None
        self._current_branch_group = None
        self._current_file_path = None
        self._current_file_kind = None

        self._rebuild_tree()
        self._show_overview()
        self.statusBar().showMessage(f"Loaded: {self._workspace_path}")

    def _group_parent_map(self) -> dict[str, set[str]]:
        parent_map: dict[str, set[str]] = {}
        if self._project is None:
            return parent_map

        for group_name, group in self._project.groups.items():
            for child_name in group.children:
                parent_map.setdefault(child_name, set()).add(group_name)
        return parent_map

    def _is_root_group(self, group_name: str) -> bool:
        if self._project is None:
            return False
        if group_name == "all":
            return False
        parent_map = self._group_parent_map()
        return group_name not in parent_map

    def _rebuild_tree(self) -> None:
        self.tree.clear()
        if self._project is None:
            return

        root = QTreeWidgetItem(["Inventory", "root"])
        root.setData(0, Qt.ItemDataRole.UserRole, ("root", None))
        self.tree.addTopLevelItem(root)
        root.setExpanded(True)

        all_item = self._build_group_item("all")
        root.addChild(all_item)

        ungrouped_item = QTreeWidgetItem(["ungrouped", "special"])
        ungrouped_item.setData(0, Qt.ItemDataRole.UserRole, ("group", "ungrouped"))
        self._style_item(ungrouped_item, "#757575", bold=True)
        for host_name in sorted(
            host_name for host_name, host in self._project.hosts.items() if not host.groups
        ):
            ungrouped_item.addChild(self._build_host_item(host_name, "ungrouped"))
        root.addChild(ungrouped_item)

        for group_name in sorted(
            group_name for group_name in self._project.groups if self._is_root_group(group_name)
        ):
            if group_name == "all":
                continue
            root.addChild(self._build_group_item(group_name))

        self.tree.expandAll()

    def _build_group_item(self, group_name: str) -> QTreeWidgetItem:
        if self._project is None:
            return QTreeWidgetItem()

        group = self._project.groups.get(group_name)
        if group is None:
            item = QTreeWidgetItem([group_name, "group"])
            item.setData(0, Qt.ItemDataRole.UserRole, ("group", group_name))
            return item

        item = QTreeWidgetItem([group_name, f"vars={len(group.variables)} hosts={len(group.hosts)}"])
        item.setData(0, Qt.ItemDataRole.UserRole, ("group", group_name))
        self._style_item(item, "#1565c0", bold=True)

        for child_name in sorted(group.children):
            if child_name in self._project.groups:
                item.addChild(self._build_group_item(child_name))

        for host_name in sorted(group.hosts):
            item.addChild(self._build_host_item(host_name, group_name))

        return item

    def _build_host_item(self, host_name: str, branch_group: str) -> QTreeWidgetItem:
        if self._project is None:
            return QTreeWidgetItem()

        host = self._project.hosts.get(host_name)
        var_count = len(host.variables) if host is not None else 0
        item = QTreeWidgetItem([host_name, f"branch={branch_group} vars={var_count}"])
        item.setData(0, Qt.ItemDataRole.UserRole, ("host", host_name, branch_group))
        self._style_item(item, "#2e7d32", bold=False)
        return item

    def _style_item(self, item: QTreeWidgetItem, color: str, bold: bool = False) -> None:
        brush = QBrush(QColor(color))
        for column in range(2):
            item.setForeground(column, brush)
        if bold:
            font = QFont()
            font.setBold(True)
            item.setFont(0, font)

    def _show_overview(self) -> None:
        if self._overview is None:
            self.overview_text.setPlainText("No workspace loaded.")
            self.issues_text.setPlainText("No workspace loaded.")
            return

        lines = ["Workspace overview", ""]
        for label, value in self._overview.stats:
            lines.append(f"{label}: {value}")
        self.overview_text.setPlainText("\n".join(lines))
        self.issues_text.setPlainText("\n".join(self._overview.issues) if self._overview.issues else "No issues found.")

        self.variables_tree.clear()
        self.trace_text.clear()
        self.files_tree.clear()
        self.file_preview.clear()

    def _on_tree_selection_changed(self) -> None:
        if self._project is None or self._scan is None:
            return

        items = self.tree.selectedItems()
        if not items:
            return

        item = items[0]
        payload = item.data(0, Qt.ItemDataRole.UserRole)
        if not payload:
            return

        kind = payload[0]
        if kind == "root":
            self._show_overview()
            self._current_mode = None
            self._current_group = None
            self._current_host = None
            self._current_branch_group = None
            return

        if kind == "group":
            group_name = payload[1]
            self._current_mode = "group"
            self._current_group = group_name
            self._current_host = None
            self._current_branch_group = None
            self._show_group_context(group_name)
            return

        if kind == "host":
            host_name = payload[1]
            branch_group = payload[2]
            self._current_mode = "host"
            self._current_group = branch_group
            self._current_host = host_name
            self._current_branch_group = branch_group
            self._show_host_context(host_name, branch_group)
            return

    def _populate_variables_tree(self, rows: list[object]) -> None:
        self.variables_tree.clear()
        for row in rows:
            item = QTreeWidgetItem([row.key, row.value_text, row.scope, row.source_path])
            item.setData(0, Qt.ItemDataRole.UserRole, row.key)
            self._style_item(item, row.color)
            self.variables_tree.addTopLevelItem(item)
        self.variables_tree.resizeColumnToContents(0)
        self.variables_tree.resizeColumnToContents(2)

    def _populate_files_tree(self, rows: list[object]) -> None:
        self.files_tree.clear()
        for row in rows:
            item = QTreeWidgetItem([row.kind, row.path])
            item.setData(0, Qt.ItemDataRole.UserRole, (row.kind, row.path))
            self._style_item(item, row.color)
            self.files_tree.addTopLevelItem(item)
        self.files_tree.resizeColumnToContents(0)

    def _show_group_context(self, group_name: str) -> None:
        if self._project is None or self._scan is None:
            return

        view = build_group_context_view(self._project, self._scan, group_name)
        self.overview_text.setPlainText("\n".join(view.summary_lines))
        self._populate_variables_tree(view.variables)
        self._populate_files_tree(view.files)
        self.trace_text.setPlainText(
            "Group context\n\n"
            f"Hosts: {', '.join(view.hosts) if view.hosts else '-'}\n"
            f"Child groups: {', '.join(view.children) if view.children else '-'}\n"
            "Select a variable to see its source path."
        )
        self.file_preview.setPlainText("")
        self.issues_text.setPlainText(
            "\n".join(self._overview.issues) if self._overview and self._overview.issues else "No issues found."
        )

    def _show_host_context(self, host_name: str, branch_group: str | None) -> None:
        if self._project is None or self._scan is None:
            return

        view = build_host_context_view(self._project, self._scan, host_name, branch_group)
        self.overview_text.setPlainText("\n".join(view.summary_lines))
        self._populate_variables_tree(view.variables)
        self._populate_files_tree(view.files)
        self.trace_text.setPlainText("Select a variable to see its trace.")
        self.file_preview.setPlainText("")
        self.issues_text.setPlainText(
            "\n".join(self._overview.issues) if self._overview and self._overview.issues else "No issues found."
        )

    def _current_variable_key(self) -> str | None:
        items = self.variables_tree.selectedItems()
        if not items:
            return None
        return str(items[0].data(0, Qt.ItemDataRole.UserRole) or "").strip() or None

    def _on_variable_selection_changed(self) -> None:
        if self._project is None or self._scan is None:
            return

        key = self._current_variable_key()
        if not key:
            return

        if self._current_mode == "host" and self._current_host is not None:
            branch_group = self._current_branch_group
            from inventory_editor.analyzer.reporting import explain_variable_for_branch
            self.trace_text.setPlainText(explain_variable_for_branch(self._project, self._current_host, branch_group, key))
        elif self._current_mode == "group" and self._current_group is not None:
            group = self._project.groups.get(self._current_group)
            if group is None:
                return
            for variable in group.variables:
                if variable.key == key:
                    self.trace_text.setPlainText(
                        "\n".join(
                            [
                                f"Group: {self._current_group}",
                                f"Variable: {key}",
                                f"Value: {variable.value}",
                                f"Source: {variable.source.source_path}",
                                f"Source type: {variable.source.source_type}",
                            ]
                        )
                    )
                    return

    def _selected_file_info(self) -> tuple[str, str] | None:
        items = self.files_tree.selectedItems()
        if not items:
            return None
        payload = items[0].data(0, Qt.ItemDataRole.UserRole)
        if not payload:
            return None
        return str(payload[0]), str(payload[1])

    def _on_file_selection_changed(self) -> None:
        info = self._selected_file_info()
        if info is None:
            self._current_file_kind = None
            self._current_file_path = None
            self.file_preview.clear()
            return

        kind, path = info
        self._current_file_kind = kind
        self._current_file_path = path
        self.file_preview.setPlainText(f"{kind}\n{path}")

    def _open_source(self) -> None:
        info = self._selected_file_info()
        if info is None:
            QMessageBox.information(self, "Open source", "Select a file first.", parent=self)
            return

        kind, path = info
        file_path = Path(path)
        if kind == "vault":
            proceed = QMessageBox.question(
                self,
                "Vault file",
                "This is an encrypted vault file. Open the raw content anyway?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if proceed != QMessageBox.StandardButton.Yes:
                return

        if not file_path.exists() and self._workspace_path is not None:
            file_path = self._workspace_path / path

        QDesktopServices.openUrl(QUrl.fromLocalFile(str(file_path.resolve())))

    def _edit_source(self) -> None:
        info = self._selected_file_info()
        if info is None:
            QMessageBox.information(self, "Edit source", "Select a file first.", parent=self)
            return

        kind, path = info
        file_path = Path(path)
        if kind == "vault":
            proceed = QMessageBox.question(
                self,
                "Vault file",
                "This is an encrypted vault file. Edit the raw content anyway?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if proceed != QMessageBox.StandardButton.Yes:
                return

        if not file_path.exists() and self._workspace_path is not None:
            file_path = self._workspace_path / path

        editor = os.environ.get("VISUAL") or os.environ.get("EDITOR")
        if not editor:
            QMessageBox.warning(self, "Editor not set", "Set EDITOR or VISUAL in your environment.", parent=self)
            return

        try:
            subprocess.Popen(shlex.split(editor) + [str(file_path.resolve())])
        except Exception as exc:
            QMessageBox.critical(self, "Edit failed", str(exc), parent=self)

    def _add_group(self) -> None:
        if self._project is None:
            return

        group_name, ok = QInputDialog.getText(self, "Add group", "Group name:")
        if not ok or not group_name.strip():
            return

        group_name = group_name.strip()
        self._project.add_group(group_name)
        self._dirty = True
        self._rebuild_tree()
        self.statusBar().showMessage(f"Added group: {group_name}")

    def _add_host(self) -> None:
        if self._project is None:
            return

        host_name, ok = QInputDialog.getText(self, "Add host", "Host name:")
        if not ok or not host_name.strip():
            return

        host_name = host_name.strip()

        target_group: str | None = None
        if self._current_mode == "group" and self._current_group not in (None, "ungrouped"):
            target_group = self._current_group
        elif self._current_mode == "host" and self._current_branch_group not in (None, "ungrouped"):
            target_group = self._current_branch_group

        self._project.add_host(host_name)
        if target_group:
            self._project.assign_host_to_group(host_name, target_group)

        self._dirty = True
        self._rebuild_tree()
        self.statusBar().showMessage(
            f"Added host: {host_name}" + (f" to {target_group}" if target_group else "")
        )

    def _prompt_existing_variable_action(self, key: str, existing_values: list[str]) -> str | None:
        box = QMessageBox(self)
        box.setWindowTitle("Variable exists")
        box.setIcon(QMessageBox.Icon.Warning)
        box.setText(f"Variable '{key}' already exists in this context.")
        box.setInformativeText(
            "Choose how to proceed.\n\n"
            f"Existing values: {', '.join(existing_values) if existing_values else '-'}"
        )
        replace_button = box.addButton("Replace", QMessageBox.ButtonRole.AcceptRole)
        append_button = box.addButton("Append", QMessageBox.ButtonRole.ActionRole)
        cancel_button = box.addButton(QMessageBox.StandardButton.Cancel)
        box.exec()

        clicked = box.clickedButton()
        if clicked == replace_button:
            return "replace"
        if clicked == append_button:
            return "append"
        if clicked == cancel_button:
            return None
        return None

    def _add_variable(self) -> None:
        if self._project is None:
            return

        if self._current_mode not in {"group", "host"}:
            QMessageBox.information(self, "Add variable", "Select a group or host first.", parent=self)
            return

        dialog_title = "Add group variable" if self._current_mode == "group" else "Add host variable"
        dialog = VariableDialog(self, dialog_title)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return

        result = dialog.result_data
        if result is None:
            return

        key, value, file_name = result
        file_name = file_name.strip() or "main.yml"
        if not file_name.endswith((".yml", ".yaml")):
            file_name += ".yml"

        if self._current_mode == "group":
            group_name = self._current_group
            if not group_name:
                return
            source_path = f"group_vars/{group_name}/{file_name}"
            existing = [
                variable.value
                for variable in self._project.groups.get(group_name, None).variables
                if variable.key == key
            ] if self._project.groups.get(group_name) is not None else []
            action = None
            if existing:
                existing_text = [str(item) for item in existing]
                if all(str(item) == str(value) for item in existing):
                    QMessageBox.information(
                        self,
                        "Already exists",
                        "The same key/value already exists in this group context. Nothing changed.",
                        parent=self,
                    )
                    return
                action = self._prompt_existing_variable_action(key, existing_text)
                if action is None:
                    return

            variable = Variable(
                key=key,
                value=value,
                scope=VariableScope.GROUP,
                owner=group_name,
                source=VariableSource(source_path=source_path, source_type="group_vars"),
            )

            if action == "replace":
                self._project.replace_variable_in_group(group_name, variable)
            else:
                self._project.add_variable_to_group(group_name, variable)

            self._dirty = True
            self._rebuild_tree()
            self.statusBar().showMessage(f"Added group variable {key} to {group_name}")
            return

        host_name = self._current_host
        branch_group = self._current_branch_group
        if not host_name:
            return

        source_path = f"host_vars/{host_name}/{file_name}"
        existing = [
            variable.value
            for variable in self._project.hosts.get(host_name, None).variables
            if variable.key == key
        ] if self._project.hosts.get(host_name) is not None else []
        action = None
        if existing:
            existing_text = [str(item) for item in existing]
            if all(str(item) == str(value) for item in existing):
                QMessageBox.information(
                    self,
                    "Already exists",
                    "The same key/value already exists on this host. Nothing changed.",
                    parent=self,
                )
                return
            action = self._prompt_existing_variable_action(key, existing_text)
            if action is None:
                return

        variable = Variable(
            key=key,
            value=value,
            scope=VariableScope.HOST,
            owner=host_name,
            source=VariableSource(source_path=source_path, source_type="host_vars"),
        )

        if action == "replace":
            self._project.replace_variable_in_host(host_name, variable)
        else:
            self._project.add_variable_to_host(host_name, variable)

        self._dirty = True
        self._rebuild_tree()
        self.statusBar().showMessage(f"Added host variable {key} to {host_name} ({branch_group})")

    def _export_workspace(self) -> None:
        if self._project is None or self._workspace_path is None:
            QMessageBox.warning(self, "Export", "Load a workspace first.", parent=self)
            return

        if self._dirty:
            proceed = QMessageBox.question(
                self,
                "Export workspace",
                "Export changes back to the loaded workspace?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if proceed != QMessageBox.StandardButton.Yes:
                return

        try:
            export_workspace(self._project, self._workspace_path)
            self._dirty = False
            self.statusBar().showMessage(f"Exported to {self._workspace_path}")
        except Exception as exc:
            QMessageBox.critical(self, "Export failed", str(exc), parent=self)

EOF

cat > inventory_editor/gui/app.py <<'EOF'
from __future__ import annotations

import sys
from pathlib import Path

from PySide6.QtWidgets import QApplication

from inventory_editor.gui.main_window import MainWindow


def main(argv: list[str] | None = None) -> int:
    args = list(sys.argv[1:] if argv is None else argv)
    workspace = Path(args[0]).expanduser().resolve() if args else None

    app = QApplication(sys.argv[:1])
    window = MainWindow(workspace=workspace)
    window.show()
    return app.exec()
EOF

cat > inventory_editor/gui/__main__.py <<'EOF'
from inventory_editor.gui.app import main

raise SystemExit(main())
EOF

cat > inventory_editor/tests/test_branch_context.py <<'EOF'
from inventory_editor.analyzer.reporting import explain_variable_for_branch
from inventory_editor.analyzer.tracing import trace_variables_for_branch
from inventory_editor.models.project import ProjectModel
from inventory_editor.models.variable import Variable, VariableScope, VariableSource


def test_branch_specific_effective_variables():
    model = ProjectModel(root_path=".")

    model.add_variable_to_group(
        "all",
        Variable(
            key="http_port",
            value=80,
            scope=VariableScope.GROUP,
            owner="all",
            source=VariableSource(
                source_path="group_vars/all/main.yml",
                source_type="group_vars",
            ),
        ),
    )

    model.add_variable_to_group(
        "group_a",
        Variable(
            key="http_port",
            value=81,
            scope=VariableScope.GROUP,
            owner="group_a",
            source=VariableSource(
                source_path="group_vars/group_a/main.yml",
                source_type="group_vars",
            ),
        ),
    )

    model.add_variable_to_group(
        "group_b",
        Variable(
            key="http_port",
            value=82,
            scope=VariableScope.GROUP,
            owner="group_b",
            source=VariableSource(
                source_path="group_vars/group_b/main.yml",
                source_type="group_vars",
            ),
        ),
    )

    model.assign_host_to_group("web01", "group_a")
    model.assign_host_to_group("web01", "group_b")

    effective_a = model.effective_variables_for_branch("web01", "group_a")
    effective_b = model.effective_variables_for_branch("web01", "group_b")

    assert effective_a["http_port"].value == 81
    assert effective_b["http_port"].value == 82


def test_trace_and_explain_branch():
    model = ProjectModel(root_path=".")

    model.add_variable_to_group(
        "all",
        Variable(
            key="debug",
            value=False,
            scope=VariableScope.GROUP,
            owner="all",
            source=VariableSource(
                source_path="group_vars/all/main.yml",
                source_type="group_vars",
            ),
        ),
    )

    model.assign_host_to_group("web01", "web")

    model.add_variable_to_host(
        "web01",
        Variable(
            key="debug",
            value=True,
            scope=VariableScope.HOST,
            owner="web01",
            source=VariableSource(
                source_path="host_vars/web01/main.yml",
                source_type="host_vars",
            ),
        ),
    )

    trace = trace_variables_for_branch(model, "web01", "web")
    assert len(trace) == 1
    assert trace[0].effective.value is True

    report = explain_variable_for_branch(model, "web01", "web", "debug")
    assert "Effective value: True" in report
    assert "group_vars/all/main.yml" in report
    assert "host_vars/web01/main.yml" in report
EOF

cat > check <<'EOF'
[HOTOVO] Specifikace projektu
[HOTOVO] Core model: ProjectModel, Host, Group, Variable, VariableSource
[HOTOVO] Precedence: all -> parent group -> child group -> host
[HOTOVO] Effective variables
[HOTOVO] Source tracing
[HOTOVO] Explain variable report
[HOTOVO] Scanner workspace
[HOTOVO] Import inventory.yml
[HOTOVO] Import group_vars
[HOTOVO] Import host_vars
[HOTOVO] Export workspace
[HOTOVO] CLI nad workspace
[HOTOVO] Rozpoznání vault souborů
[HOTOVO] Rozpoznání backup souborů
[HOTOVO] Vault metadata (version, cipher)
[HOTOVO] Host search
[HOTOVO] Variable placement advisor
[HOTOVO] Reálný test na produkčním inventory
[HOTOVO] GUI skeleton
[HOTOVO] GUI redesign podle Ansible workflow
[HOTOVO] Hlavní strom: all / ungrouped / groups / hosty v branch context
[HOTOVO] Host + Group Context
[HOTOVO] Detail hosta: all/group/host effective vars, source trace, source paths
[HOTOVO] Zobrazení souborů group_vars/host_vars/vault
[HOTOVO] Barevné odlišení all/group/host/vault
[HOTOVO] Otevření zdrojového souboru
[HOTOVO] Editace group_vars/host_vars souboru
[HOTOVO] Přidání skupiny
[HOTOVO] Přidání hosta do skupiny
[HOTOVO] Přidání proměnné do group/host s volbou souboru
[HOTOVO] Workspace statistics

[TEĎ] Vault content editing
[TEĎ] Vault password source autodetection
[TEĎ] Playbook discovery
[TEĎ] Tag discovery
[TEĎ] CLI command builder pro ansible-playbook
[TEĎ] Přesnější editace zachovávající komentáře při zápisu
[TEĎ] Rozšířený conflict analyzer
[TEĎ] Multi-inventory / více prostředí
[TEĎ] Průvodce pro začátečníka

[SKIP NOW] Plné parsování a editace ansible-vault obsahu
[SKIP NOW] Dynamické inventory
[SKIP NOW] Kompletní statická analýza všech playbook includes/imports
[SKIP NOW] Git autocommit jako default
[SKIP NOW] Kompletní refaktor exportu na všechna tematická data
EOF

echo "RELEASE-0028 applied"
