#!/usr/bin/env bash
set -e

mkdir -p inventory_editor/analyzer

cat > inventory_editor/analyzer/file_classifier.py <<'EOF'
from enum import Enum
from pathlib import Path


class FileClassification(str, Enum):
    INVENTORY_FILE = "inventory_file"
    VARIABLE_FILE = "variable_file"
    VAULT_FILE = "vault_file"
    BACKUP_FILE = "backup_file"
    UNKNOWN = "unknown"


def classify_file(path: str) -> FileClassification:
    p = Path(path)

    name = p.name.lower()

    if name.endswith(".yml") or name.endswith(".yaml"):
        if name == "vault.yml":
            return FileClassification.VAULT_FILE

        if "group_vars" in p.parts or "host_vars" in p.parts:
            return FileClassification.VARIABLE_FILE

        return FileClassification.INVENTORY_FILE

    if ".yml-" in name or ".yaml-" in name:
        return FileClassification.BACKUP_FILE

    return FileClassification.UNKNOWN
EOF

cat > inventory_editor/tests/test_file_classifier.py <<'EOF'
from inventory_editor.analyzer.file_classifier import (
    FileClassification,
    classify_file,
)


def test_inventory_file():
    assert (
        classify_file("inventory.yml")
        == FileClassification.INVENTORY_FILE
    )


def test_variable_file():
    assert (
        classify_file("group_vars/web/90-network.yml")
        == FileClassification.VARIABLE_FILE
    )


def test_vault_file():
    assert (
        classify_file("group_vars/web/vault.yml")
        == FileClassification.VAULT_FILE
    )


def test_backup_file():
    assert (
        classify_file("inventory.yml-20240522")
        == FileClassification.BACKUP_FILE
    )


def test_unknown_file():
    assert (
        classify_file("notes.txt")
        == FileClassification.UNKNOWN
    )
EOF

echo "RELEASE-0019 applied"
