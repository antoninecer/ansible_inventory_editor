#!/usr/bin/env bash
set -e

cat > inventory_editor/models/workspace.py <<'EOF'
from dataclasses import dataclass, field

from inventory_editor.models.vault import VaultFile


@dataclass(slots=True)
class WorkspaceScanResult:
    root_path: str

    inventory_files: list[str] = field(default_factory=list)
    group_var_paths: list[str] = field(default_factory=list)
    host_var_paths: list[str] = field(default_factory=list)
    backup_files: list[str] = field(default_factory=list)
    vault_files: list[str] = field(default_factory=list)
    vault_metadata: list[VaultFile] = field(default_factory=list)
    unknown_paths: list[str] = field(default_factory=list)
EOF

cat > inventory_editor/io/scanner.py <<'EOF'
from __future__ import annotations

from pathlib import Path

from inventory_editor.analyzer.file_classifier import FileClassification, classify_file
from inventory_editor.analyzer.vault import detect_vault_file
from inventory_editor.models.workspace import WorkspaceScanResult


def scan_inventory_workspace(root_path: str | Path) -> WorkspaceScanResult:
    root = Path(root_path).expanduser().resolve()
    result = WorkspaceScanResult(root_path=str(root))

    if not root.exists():
        raise FileNotFoundError(root)

    for path in sorted(root.rglob("*")):
        if path.is_dir():
            continue

        rel = path.relative_to(root).as_posix()
        classification = classify_file(rel)

        if classification == FileClassification.INVENTORY_FILE:
            result.inventory_files.append(rel)
        elif classification == FileClassification.VARIABLE_FILE:
            if rel.startswith("group_vars/"):
                result.group_var_paths.append(rel)
            elif rel.startswith("host_vars/"):
                result.host_var_paths.append(rel)
            else:
                result.unknown_paths.append(rel)
        elif classification == FileClassification.VAULT_FILE:
            result.vault_files.append(rel)
            vault = detect_vault_file(path)
            if vault is not None:
                result.vault_metadata.append(vault)
        elif classification == FileClassification.BACKUP_FILE:
            result.backup_files.append(rel)
        else:
            result.unknown_paths.append(rel)

    return result
EOF

cat > inventory_editor/cli.py <<'EOF'
from __future__ import annotations

import sys
from pathlib import Path

from inventory_editor.analyzer.workspace_quality import analyze_workspace_scan
from inventory_editor.io.workspace_loader import load_inventory_workspace


def main(argv: list[str] | None = None) -> int:
    args = list(sys.argv[1:] if argv is None else argv)

    if not args:
        print("Usage: python -m inventory_editor <workspace>")
        return 2

    workspace = Path(args[0]).expanduser().resolve()

    project, scan = load_inventory_workspace(workspace)
    report = analyze_workspace_scan(scan)

    print(f"Workspace: {workspace}")
    print(f"Groups: {project.group_count()}")
    print(f"Hosts: {project.host_count()}")
    print(f"Inventory files: {len(scan.inventory_files)}")
    print(f"Group var files: {len(scan.group_var_paths)}")
    print(f"Host var files: {len(scan.host_var_paths)}")
    print(f"Vault files: {len(scan.vault_files)}")
    print(f"Backup files: {len(scan.backup_files)}")
    print(f"Unknown files: {len(scan.unknown_paths)}")

    if scan.vault_metadata:
        print("Vault metadata:")
        for vault in scan.vault_metadata:
            print(
                f"- {vault.source_path} "
                f"(version={vault.vault_version}, cipher={vault.cipher})"
            )

    if report.issues:
        print("Issues:")
        for issue in report.issues:
            print(f"- [{issue.severity.value}] {issue.message}")

    return 0
EOF

cat > inventory_editor/tests/test_vault_detection.py <<'EOF'
from inventory_editor.analyzer.vault import detect_vault_file
from inventory_editor.io.scanner import scan_inventory_workspace


def test_detect_ansible_vault(tmp_path):
    vault_file = tmp_path / "vault.yml"

    vault_file.write_text(
        "$ANSIBLE_VAULT;1.1;AES256\n"
        "abcdef\n",
        encoding="utf-8",
    )

    vault = detect_vault_file(vault_file)

    assert vault is not None
    assert vault.vault_version == "1.1"
    assert vault.cipher == "AES256"


def test_scan_collects_vault_metadata(tmp_path):
    root = tmp_path / "inventory"
    (root / "group_vars" / "web").mkdir(parents=True)
    (root / "group_vars" / "web" / "vault.yml").write_text(
        "$ANSIBLE_VAULT;1.1;AES256\nabcdef\n",
        encoding="utf-8",
    )

    scan = scan_inventory_workspace(root)

    assert len(scan.vault_files) == 1
    assert len(scan.vault_metadata) == 1
    assert scan.vault_metadata[0].cipher == "AES256"
EOF

echo "RELEASE-0024 applied"
