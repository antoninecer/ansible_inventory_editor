#!/usr/bin/env bash
set -e

mkdir -p inventory_editor/io
mkdir -p inventory_editor/tests

cat > inventory_editor/io/inventory_loader.py <<'EOF'
from __future__ import annotations

from pathlib import Path

from ruamel.yaml import YAML

from inventory_editor.models.project import ProjectModel


yaml = YAML(typ="safe")


def load_inventory_file(path: str | Path) -> ProjectModel:
    inventory_path = Path(path).expanduser().resolve()
    if not inventory_path.exists():
        raise FileNotFoundError(inventory_path)

    data = yaml.load(inventory_path.read_text(encoding="utf-8")) or {}
    if not isinstance(data, dict):
        raise ValueError("Inventory root must be a mapping")

    project = ProjectModel(root_path=str(inventory_path.parent), inventory_file=inventory_path.name)

    for group_name, group_data in data.items():
        if not isinstance(group_data, dict):
            continue

        project.add_group(group_name)

        hosts = group_data.get("hosts", {})
        if isinstance(hosts, dict):
            for host_name in hosts.keys():
                project.assign_host_to_group(host_name, group_name)

        children = group_data.get("children", {})
        if isinstance(children, dict):
            for child_name in children.keys():
                project.add_group(child_name)
                project.groups[group_name].add_child(child_name)

    return project
EOF

cat > inventory_editor/tests/test_inventory_loader.py <<'EOF'
from inventory_editor.io.inventory_loader import load_inventory_file


def test_load_simple_inventory(tmp_path):
    inventory_file = tmp_path / "inventory.yml"
    inventory_file.write_text(
        """
all:
  hosts:
    localhost:
web:
  hosts:
    web01:
  children:
    all:
""".strip()
        + "\n",
        encoding="utf-8",
    )

    project = load_inventory_file(inventory_file)

    assert "all" in project.groups
    assert "web" in project.groups
    assert "localhost" in project.hosts
    assert "web01" in project.hosts
    assert "web" in project.hosts["web01"].groups
    assert "localhost" in project.groups["all"].hosts
EOF

echo "RELEASE-0009 applied"
