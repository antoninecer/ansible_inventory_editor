#!/usr/bin/env bash
set -e

cat > inventory_editor/cli.py <<'EOF'
from __future__ import annotations

import sys
from pathlib import Path

from inventory_editor.analyzer.workspace_quality import analyze_workspace_scan
from inventory_editor.io.workspace_loader import load_inventory_workspace


def main(argv: list[str] | None = None) -> int:
    args = list(sys.argv[1:] if argv is None else argv)

    if not args:
        print("Usage: python -m inventory_editor <workspace>")
        return 2

    workspace = Path(args[0]).expanduser().resolve()

    project, scan = load_inventory_workspace(workspace)
    report = analyze_workspace_scan(scan)

    print(f"Workspace: {workspace}")
    print(f"Groups: {project.group_count()}")
    print(f"Hosts: {project.host_count()}")
    print(f"Inventory files: {len(scan.inventory_files)}")
    print(f"Group var files: {len(scan.group_var_paths)}")
    print(f"Host var files: {len(scan.host_var_paths)}")
    print(f"Unknown files: {len(scan.unknown_paths)}")

    if report.issues:
        print("Issues:")
        for issue in report.issues:
            print(f"- [{issue.severity.value}] {issue.message}")

    return 0
EOF

cat > inventory_editor/__main__.py <<'EOF'
from inventory_editor.cli import main

raise SystemExit(main())
EOF

cat > inventory_editor/tests/test_cli.py <<'EOF'
from inventory_editor.cli import main


def test_cli_prints_summary(tmp_path, capsys):
    root = tmp_path / "inventory"
    (root / "group_vars" / "all").mkdir(parents=True)
    (root / "host_vars" / "web01").mkdir(parents=True)

    (root / "inventory.yml").write_text(
        """
all:
  hosts:
    localhost:
web:
  hosts:
    web01:
""".strip()
        + "\n",
        encoding="utf-8",
    )

    (root / "group_vars" / "all" / "main.yml").write_text("debug: true\n", encoding="utf-8")
    (root / "host_vars" / "web01" / "main.yml").write_text("http_port: 8080\n", encoding="utf-8")
    (root / "notes.txt").write_text("ignore me\n", encoding="utf-8")

    rc = main([str(root)])
    captured = capsys.readouterr()

    assert rc == 0
    assert "Workspace:" in captured.out
    assert "Groups:" in captured.out
    assert "Unknown files: 1" in captured.out
EOF

echo "RELEASE-0018 applied"
