#!/usr/bin/env bash
set -e

cat > inventory_editor/io/workspace_exporter.py <<'EOF'
from __future__ import annotations

from collections import defaultdict
from pathlib import Path

from ruamel.yaml import YAML

from inventory_editor.models.project import ProjectModel


yaml = YAML()
yaml.default_flow_style = False
yaml.sort_base_mapping_type_on_output = False


def _write_yaml(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as fh:
        yaml.dump(data, fh)


def _group_vars_by_source(items) -> dict[str, dict]:
    grouped: dict[str, dict] = defaultdict(dict)
    for variable in items:
        source_path = variable.source.source_path
        file_name = Path(source_path).name if source_path else "main.yml"
        if file_name in {"", "."}:
            file_name = "main.yml"
        grouped[file_name][variable.key] = variable.value
    return dict(grouped)


def export_workspace(project: ProjectModel, target_root: str | Path) -> None:
    root = Path(target_root).expanduser().resolve()
    root.mkdir(parents=True, exist_ok=True)

    inventory_data: dict[str, dict] = {}

    for group_name, group in project.groups.items():
        group_block: dict[str, dict] = {}

        if group.hosts:
            group_block["hosts"] = {host_name: None for host_name in sorted(group.hosts)}

        if group.children:
            group_block["children"] = {child_name: None for child_name in sorted(group.children)}

        if group_block:
            inventory_data[group_name] = group_block

    _write_yaml(root / "inventory.yml", inventory_data)

    for group_name, group in project.groups.items():
        if not group.variables:
            continue

        by_file = _group_vars_by_source(group.variables)
        for file_name, vars_data in by_file.items():
            _write_yaml(root / "group_vars" / group_name / file_name, vars_data)

    for host_name, host in project.hosts.items():
        if not host.variables:
            continue

        by_file = _group_vars_by_source(host.variables)
        for file_name, vars_data in by_file.items():
            _write_yaml(root / "host_vars" / host_name / file_name, vars_data)
EOF

cat > inventory_editor/tests/test_workspace_exporter.py <<'EOF'
from inventory_editor.io.workspace_exporter import export_workspace
from inventory_editor.models.project import ProjectModel
from inventory_editor.models.variable import Variable, VariableScope, VariableSource


def test_export_workspace_preserves_source_file_names(tmp_path):
    project = ProjectModel(root_path=str(tmp_path))

    project.add_variable_to_group(
        "web",
        Variable(
            key="web_port",
            value=80,
            scope=VariableScope.GROUP,
            owner="web",
            source=VariableSource(
                source_path="group_vars/web/main.yml",
                source_type="group_vars",
            ),
        ),
    )

    project.add_variable_to_group(
        "web",
        Variable(
            key="secret_token",
            value="abc",
            scope=VariableScope.GROUP,
            owner="web",
            source=VariableSource(
                source_path="group_vars/web/vault.yml",
                source_type="group_vars",
            ),
        ),
    )

    project.assign_host_to_group("web01", "web")

    project.add_variable_to_host(
        "web01",
        Variable(
            key="http_port",
            value=8080,
            scope=VariableScope.HOST,
            owner="web01",
            source=VariableSource(
                source_path="host_vars/web01/nginx.yml",
                source_type="host_vars",
            ),
        ),
    )

    export_workspace(project, tmp_path / "out")

    assert (tmp_path / "out" / "group_vars" / "web" / "main.yml").exists()
    assert (tmp_path / "out" / "group_vars" / "web" / "vault.yml").exists()
    assert (tmp_path / "out" / "host_vars" / "web01" / "nginx.yml").exists()
EOF

echo "RELEASE-0017 applied"
