from __future__ import annotations

from pathlib import Path

from ruamel.yaml import YAML

from inventory_editor.models.project import ProjectModel
from inventory_editor.models.variable import Variable, VariableScope, VariableSource


yaml = YAML(typ="safe")

IGNORED_FILE_SUFFIXES = {".bak", ".tmp", ".swp", ".swo"}
def _is_ansible_vault(path: Path) -> bool:
    try:
        first_line = path.read_text(encoding="utf-8").splitlines()[0]
    except Exception:
        return False
    return first_line.startswith("$ANSIBLE_VAULT;")

def _load_yaml_mapping(path: Path) -> dict:
    data = yaml.load(path.read_text(encoding="utf-8")) or {}
    if not isinstance(data, dict):
        raise ValueError(f"YAML root in {path} must be a mapping")
    return data


def load_inventory_file(path: str | Path) -> ProjectModel:
    inventory_path = Path(path).expanduser().resolve()
    if not inventory_path.exists():
        raise FileNotFoundError(inventory_path)

    data = _load_yaml_mapping(inventory_path)

    project = ProjectModel(root_path=str(inventory_path.parent), inventory_file=inventory_path.name)

    for group_name, group_data in data.items():
        if not isinstance(group_data, dict):
            continue

        project.add_group(group_name)

        hosts = group_data.get("hosts", {})
        if isinstance(hosts, dict):
            for host_name in hosts.keys():
                project.assign_host_to_group(host_name, group_name)

        children = group_data.get("children", {})
        if isinstance(children, dict):
            for child_name in children.keys():
                project.add_group(child_name)
                project.groups[group_name].add_child(child_name)

    return project


def _iter_var_files(root: Path, scope_root: Path) -> list[Path]:
    if not scope_root.exists():
        return []

    files: list[Path] = []
    for path in sorted(scope_root.rglob("*")):
        if not path.is_file():
            continue
        if path.suffix in IGNORED_FILE_SUFFIXES:
            continue
        if path.name.startswith("."):
            continue
        files.append(path)
    return files


def load_workspace_variables(project: ProjectModel, workspace_root: str | Path) -> None:
    root = Path(workspace_root).expanduser().resolve()
    if not root.exists():
        raise FileNotFoundError(root)

    group_vars_root = root / "group_vars"
    if group_vars_root.exists():
        for group_dir in group_vars_root.iterdir():
            if not group_dir.is_dir():
                continue
            group_name = group_dir.name
            for file_path in _iter_var_files(root, group_dir):
                if _is_ansible_vault(file_path):
                    continue
                data = _load_yaml_mapping(file_path)
                for key, value in data.items():
                    variable = Variable(
                        key=key,
                        value=value,
                        scope=VariableScope.GROUP,
                        owner=group_name,
                        source=VariableSource(
                            source_path=str(file_path.relative_to(root)),
                            source_type="group_vars",
                        ),
                    )
                    project.add_variable_to_group(group_name, variable)

    host_vars_root = root / "host_vars"
    if host_vars_root.exists():
        for host_dir in host_vars_root.iterdir():
            if not host_dir.is_dir():
                continue
            host_name = host_dir.name
            for file_path in _iter_var_files(root, host_dir):
                data = _load_yaml_mapping(file_path)
                for key, value in data.items():
                    variable = Variable(
                        key=key,
                        value=value,
                        scope=VariableScope.HOST,
                        owner=host_name,
                        source=VariableSource(
                            source_path=str(file_path.relative_to(root)),
                            source_type="host_vars",
                        ),
                    )
                    project.add_variable_to_host(host_name, variable)
