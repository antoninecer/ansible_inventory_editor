from __future__ import annotations

from collections import defaultdict
from pathlib import Path

from ruamel.yaml import YAML

from inventory_editor.models.project import ProjectModel


yaml = YAML()
yaml.default_flow_style = False
yaml.sort_base_mapping_type_on_output = False


def _write_yaml(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as fh:
        yaml.dump(data, fh)


def _group_vars_by_source(items) -> dict[str, dict]:
    grouped: dict[str, dict] = defaultdict(dict)
    for variable in items:
        source_path = variable.source.source_path
        file_name = Path(source_path).name if source_path else "main.yml"
        if file_name in {"", "."}:
            file_name = "main.yml"
        grouped[file_name][variable.key] = variable.value
    return dict(grouped)


def export_workspace(project: ProjectModel, target_root: str | Path) -> None:
    root = Path(target_root).expanduser().resolve()
    root.mkdir(parents=True, exist_ok=True)

    inventory_data: dict[str, dict] = {}

    for group_name, group in project.groups.items():
        group_block: dict[str, dict] = {}

        if group.hosts:
            group_block["hosts"] = {host_name: None for host_name in sorted(group.hosts)}

        if group.children:
            group_block["children"] = {child_name: None for child_name in sorted(group.children)}

        if group_block:
            inventory_data[group_name] = group_block

    _write_yaml(root / "inventory.yml", inventory_data)

    for group_name, group in project.groups.items():
        if not group.variables:
            continue

        by_file = _group_vars_by_source(group.variables)
        for file_name, vars_data in by_file.items():
            _write_yaml(root / "group_vars" / group_name / file_name, vars_data)

    for host_name, host in project.hosts.items():
        if not host.variables:
            continue

        by_file = _group_vars_by_source(host.variables)
        for file_name, vars_data in by_file.items():
            _write_yaml(root / "host_vars" / host_name / file_name, vars_data)
