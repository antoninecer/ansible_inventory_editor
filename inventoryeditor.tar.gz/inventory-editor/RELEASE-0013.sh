#!/usr/bin/env bash
set -e

cat > inventory_editor/io/workspace_loader.py <<'EOF'
from __future__ import annotations

from pathlib import Path

from inventory_editor.io.inventory_loader import load_inventory_file, load_workspace_variables
from inventory_editor.io.scanner import scan_inventory_workspace
from inventory_editor.models.project import ProjectModel


def load_inventory_workspace(root_path: str | Path) -> tuple[ProjectModel, object]:
    scan = scan_inventory_workspace(root_path)

    root = Path(root_path).expanduser().resolve()
    inventory_file = None
    if "inventory.yml" in scan.inventory_files:
        inventory_file = root / "inventory.yml"
    elif scan.inventory_files:
        inventory_file = root / scan.inventory_files[0]

    if inventory_file is None:
        raise FileNotFoundError("No inventory YAML file found in workspace")

    project = load_inventory_file(inventory_file)
    load_workspace_variables(project, root)

    return project, scan
EOF

cat > inventory_editor/tests/test_workspace_loader.py <<'EOF'
from inventory_editor.io.workspace_loader import load_inventory_workspace


def test_load_inventory_workspace(tmp_path):
    root = tmp_path / "inventory"
    (root / "group_vars" / "all").mkdir(parents=True)
    (root / "host_vars" / "web01").mkdir(parents=True)

    (root / "inventory.yml").write_text(
        """
all:
  hosts:
    localhost:
web:
  hosts:
    web01:
""".strip()
        + "\n",
        encoding="utf-8",
    )

    (root / "group_vars" / "all" / "main.yml").write_text("debug: true\n", encoding="utf-8")
    (root / "host_vars" / "web01" / "main.yml").write_text("http_port: 8080\n", encoding="utf-8")

    project, scan = load_inventory_workspace(root)

    assert "inventory.yml" in scan.inventory_files
    assert project.groups["all"].variables[0].key == "debug"
    assert project.hosts["web01"].variables[0].key == "http_port"
EOF

echo "RELEASE-0013 applied"
