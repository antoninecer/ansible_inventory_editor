#!/usr/bin/env bash
set -e

cat > inventory_editor/models/workspace.py <<'EOF'
from dataclasses import dataclass, field


@dataclass(slots=True)
class WorkspaceScanResult:
    root_path: str

    inventory_files: list[str] = field(default_factory=list)
    group_var_paths: list[str] = field(default_factory=list)
    host_var_paths: list[str] = field(default_factory=list)
    backup_files: list[str] = field(default_factory=list)
    vault_files: list[str] = field(default_factory=list)
    unknown_paths: list[str] = field(default_factory=list)
EOF

cat > inventory_editor/io/scanner.py <<'EOF'
from __future__ import annotations

from pathlib import Path

from inventory_editor.analyzer.file_classifier import FileClassification, classify_file
from inventory_editor.models.workspace import WorkspaceScanResult


def scan_inventory_workspace(root_path: str | Path) -> WorkspaceScanResult:
    root = Path(root_path).expanduser().resolve()
    result = WorkspaceScanResult(root_path=str(root))

    if not root.exists():
        raise FileNotFoundError(root)

    for path in sorted(root.rglob("*")):
        if path.is_dir():
            continue

        rel = path.relative_to(root).as_posix()
        classification = classify_file(rel)

        if classification == FileClassification.INVENTORY_FILE:
            result.inventory_files.append(rel)
        elif classification == FileClassification.VARIABLE_FILE:
            if rel.startswith("group_vars/"):
                result.group_var_paths.append(rel)
            elif rel.startswith("host_vars/"):
                result.host_var_paths.append(rel)
            else:
                result.unknown_paths.append(rel)
        elif classification == FileClassification.VAULT_FILE:
            result.vault_files.append(rel)
        elif classification == FileClassification.BACKUP_FILE:
            result.backup_files.append(rel)
        else:
            result.unknown_paths.append(rel)

    return result
EOF

cat > inventory_editor/analyzer/workspace_quality.py <<'EOF'
from dataclasses import dataclass

from inventory_editor.analyzer.issues import Issue, IssueSeverity
from inventory_editor.models.workspace import WorkspaceScanResult


@dataclass(slots=True)
class WorkspaceQualityReport:
    issues: list[Issue]


def analyze_workspace_scan(scan: WorkspaceScanResult) -> WorkspaceQualityReport:
    issues: list[Issue] = []

    for path in scan.unknown_paths:
        issues.append(
            Issue(
                severity=IssueSeverity.C,
                message=f"Unknown file in inventory workspace: {path}",
                source_path=path,
            )
        )

    return WorkspaceQualityReport(issues=issues)
EOF

cat > inventory_editor/cli.py <<'EOF'
from __future__ import annotations

import sys
from pathlib import Path

from inventory_editor.analyzer.workspace_quality import analyze_workspace_scan
from inventory_editor.io.workspace_loader import load_inventory_workspace


def main(argv: list[str] | None = None) -> int:
    args = list(sys.argv[1:] if argv is None else argv)

    if not args:
        print("Usage: python -m inventory_editor <workspace>")
        return 2

    workspace = Path(args[0]).expanduser().resolve()

    project, scan = load_inventory_workspace(workspace)
    report = analyze_workspace_scan(scan)

    print(f"Workspace: {workspace}")
    print(f"Groups: {project.group_count()}")
    print(f"Hosts: {project.host_count()}")
    print(f"Inventory files: {len(scan.inventory_files)}")
    print(f"Group var files: {len(scan.group_var_paths)}")
    print(f"Host var files: {len(scan.host_var_paths)}")
    print(f"Vault files: {len(scan.vault_files)}")
    print(f"Backup files: {len(scan.backup_files)}")
    print(f"Unknown files: {len(scan.unknown_paths)}")

    if report.issues:
        print("Issues:")
        for issue in report.issues:
            print(f"- [{issue.severity.value}] {issue.message}")

    return 0
EOF

cat > inventory_editor/tests/test_scanner.py <<'EOF'
from inventory_editor.io.scanner import scan_inventory_workspace


def test_scan_inventory_workspace(tmp_path):
    root = tmp_path / "inventory"
    (root / "group_vars" / "all").mkdir(parents=True)
    (root / "group_vars" / "web").mkdir(parents=True)
    (root / "host_vars" / "web01").mkdir(parents=True)

    (root / "inventory.yml").write_text("---\n", encoding="utf-8")
    (root / "group_vars" / "all" / "main.yml").write_text("x: 1\n", encoding="utf-8")
    (root / "group_vars" / "web" / "main.yml").write_text("y: 2\n", encoding="utf-8")
    (root / "host_vars" / "web01" / "main.yml").write_text("z: 3\n", encoding="utf-8")
    (root / "inventory.yml-20240522").write_text("backup\n", encoding="utf-8")
    (root / "notes.txt").write_text("ignore me\n", encoding="utf-8")

    result = scan_inventory_workspace(root)

    assert "inventory.yml" in result.inventory_files
    assert "group_vars/all/main.yml" in result.group_var_paths
    assert "group_vars/web/main.yml" in result.group_var_paths
    assert "host_vars/web01/main.yml" in result.host_var_paths
    assert "inventory.yml-20240522" in result.backup_files
    assert "notes.txt" in result.unknown_paths
EOF

echo "RELEASE-0020 applied"
