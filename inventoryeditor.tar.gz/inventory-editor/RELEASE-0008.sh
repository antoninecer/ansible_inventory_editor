#!/usr/bin/env bash
set -e

mkdir -p inventory_editor/io
mkdir -p inventory_editor/models
mkdir -p inventory_editor/tests

cat > inventory_editor/models/workspace.py <<'EOF'
from dataclasses import dataclass, field


@dataclass(slots=True)
class WorkspaceScanResult:
    root_path: str

    inventory_files: list[str] = field(default_factory=list)
    group_var_paths: list[str] = field(default_factory=list)
    host_var_paths: list[str] = field(default_factory=list)
    unknown_paths: list[str] = field(default_factory=list)
EOF

cat > inventory_editor/io/scanner.py <<'EOF'
from __future__ import annotations

from pathlib import Path

from inventory_editor.models.workspace import WorkspaceScanResult


def scan_inventory_workspace(root_path: str | Path) -> WorkspaceScanResult:
    root = Path(root_path).expanduser().resolve()
    result = WorkspaceScanResult(root_path=str(root))

    if not root.exists():
        raise FileNotFoundError(root)

    for path in sorted(root.rglob("*")):
        rel = path.relative_to(root).as_posix()

        if path.is_dir():
            continue

        parts = rel.split("/")
        name = path.name

        if len(parts) == 1 and name.endswith((".yml", ".yaml")):
            result.inventory_files.append(rel)
            continue

        if len(parts) >= 3 and parts[0] == "group_vars":
            result.group_var_paths.append(rel)
            continue

        if len(parts) >= 3 and parts[0] == "host_vars":
            result.host_var_paths.append(rel)
            continue

        result.unknown_paths.append(rel)

    return result
EOF

cat > inventory_editor/tests/test_scanner.py <<'EOF'
from inventory_editor.io.scanner import scan_inventory_workspace


def test_scan_inventory_workspace(tmp_path):
    root = tmp_path / "inventory"
    (root / "group_vars" / "all").mkdir(parents=True)
    (root / "group_vars" / "web").mkdir(parents=True)
    (root / "host_vars" / "web01").mkdir(parents=True)

    (root / "inventory.yml").write_text("---\n", encoding="utf-8")
    (root / "group_vars" / "all" / "main.yml").write_text("x: 1\n", encoding="utf-8")
    (root / "group_vars" / "web" / "main.yml").write_text("y: 2\n", encoding="utf-8")
    (root / "host_vars" / "web01" / "main.yml").write_text("z: 3\n", encoding="utf-8")
    (root / "notes.txt").write_text("ignore me\n", encoding="utf-8")

    result = scan_inventory_workspace(root)

    assert "inventory.yml" in result.inventory_files
    assert "group_vars/all/main.yml" in result.group_var_paths
    assert "group_vars/web/main.yml" in result.group_var_paths
    assert "host_vars/web01/main.yml" in result.host_var_paths
    assert "notes.txt" in result.unknown_paths
EOF

echo "RELEASE-0008 applied"
